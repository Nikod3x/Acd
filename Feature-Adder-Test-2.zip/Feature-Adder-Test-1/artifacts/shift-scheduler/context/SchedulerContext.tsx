import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

export type ShiftLabel = "A" | "B" | "C" | "W/O" | "L" | "OT" | "ABS" | "G";

export interface ShiftDef {
  label: ShiftLabel | string;
  full: string;
  bg: string;
  border: string;
  text: string;
}

export const SHIFT_DEFS: ShiftDef[] = [
  { label: "A",   full: "A Shift",  bg: "#0d2137", border: "#3b9ede", text: "#3b9ede" },
  { label: "B",   full: "B Shift",  bg: "#1a2b0d", border: "#6bbf3b", text: "#6bbf3b" },
  { label: "C",   full: "C Shift",  bg: "#2b1a0d", border: "#e0912a", text: "#e0912a" },
  { label: "G",   full: "G Shift",  bg: "#2d0d1a", border: "#ff2d78", text: "#ff2d78" },
  { label: "W/O", full: "Week Off", bg: "#1e0d2e", border: "#a855f7", text: "#a855f7" },
  { label: "L",   full: "Leave",    bg: "#2d0d0d", border: "#ef4444", text: "#ef4444" },
  { label: "OT",  full: "Overtime", bg: "#0d2d2d", border: "#14b8a6", text: "#14b8a6" },
  { label: "ABS", full: "Absent",   bg: "#2d2d0d", border: "#eab308", text: "#eab308" },
];

export const SHIFT_DEFS_LIGHT: ShiftDef[] = [
  { label: "A",   full: "A Shift",  bg: "#dbeeff", border: "#1565c0", text: "#1565c0" },
  { label: "B",   full: "B Shift",  bg: "#e0f5cc", border: "#2e7d1e", text: "#2e7d1e" },
  { label: "C",   full: "C Shift",  bg: "#fff0d6", border: "#b35a00", text: "#b35a00" },
  { label: "G",   full: "G Shift",  bg: "#ffd0e0", border: "#cc0055", text: "#cc0055" },
  { label: "W/O", full: "Week Off", bg: "#f0dcff", border: "#8c3cdc", text: "#8c3cdc" },
  { label: "L",   full: "Leave",    bg: "#ffdddd", border: "#b91c1c", text: "#b91c1c" },
  { label: "OT",  full: "Overtime", bg: "#d2f5f0", border: "#0e786e", text: "#0e786e" },
  { label: "ABS", full: "Absent",   bg: "#fff5c8", border: "#a07800", text: "#a07800" },
];

export const MONTH_NAMES = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December",
];
export const DAY_SHORT = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
export const NON_WORKING = new Set(["W/O","L","ABS"]);

export type ScheduleData = Record<string, Record<string, Record<number, string | null>>>;

export interface ShiftCounts {
  [key: string]: number;
  total: number;
  off: number;
}

function getDaysInMonth(y: number, m: number) {
  return new Date(y, m + 1, 0).getDate();
}
function getFirstDay(y: number, m: number) {
  return new Date(y, m, 1).getDay();
}
export function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

const DEFAULT_EMPLOYEES = ["SURYA KANTA MEDOK", "BY ANTHREAST"];
const LS_KEY = "shiftScheduler.v3";

interface SchedulerContextType {
  year: number;
  month: number;
  employees: string[];
  schedule: ScheduleData;
  showColors: boolean;
  appTheme: "dark" | "light";
  vibrateOnTap: boolean;
  daysInMonth: number;
  firstDay: number;
  monthKey: string;
  getShift: (emp: string, d: number) => string | null;
  setShift: (emp: string, d: number, val: string | null) => void;
  setYear: (y: number) => void;
  setMonth: (m: number) => void;
  prevMonth: () => void;
  nextMonth: () => void;
  addEmployee: (name: string) => string;
  removeEmployee: (name: string) => void;
  setShowColors: (v: boolean) => void;
  setAppTheme: (t: "dark" | "light") => void;
  setVibrateOnTap: (v: boolean) => void;
  clearMonth: () => void;
  autoGenerate: () => void;
  applyBulk: (from: number, to: number, shift: string, target: string) => string;
  getCounts: (emp: string) => ShiftCounts;
  getShiftDefs: () => ShiftDef[];
  getDaysArray: () => number[];
  restoreData: (data: { schedule?: ScheduleData; employees?: string[]; showColors?: boolean; appTheme?: "dark" | "light" }) => void;
}

const SchedulerContext = createContext<SchedulerContextType | null>(null);

export function SchedulerProvider({ children }: { children: React.ReactNode }) {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [employees, setEmployees] = useState<string[]>(DEFAULT_EMPLOYEES);
  const [schedule, setSchedule] = useState<ScheduleData>({});
  const [showColors, setShowColors] = useState(true);
  const [appTheme, setAppTheme] = useState<"dark" | "light">("dark");
  const [vibrateOnTap, setVibrateOnTap] = useState(true);
  const loadedRef = useRef(false);

  useEffect(() => {
    AsyncStorage.getItem(LS_KEY).then((raw) => {
      if (raw) {
        try {
          const data = JSON.parse(raw);
          if (data.schedule) setSchedule(data.schedule);
          if (Array.isArray(data.employees) && data.employees.length)
            setEmployees(data.employees);
          if (typeof data.showColors === "boolean") setShowColors(data.showColors);
          if (data.appTheme === "dark" || data.appTheme === "light") setAppTheme(data.appTheme);
          if (typeof data.vibrateOnTap === "boolean") setVibrateOnTap(data.vibrateOnTap);
        } catch {}
      }
      loadedRef.current = true;
    });
  }, []);

  useEffect(() => {
    if (!loadedRef.current) return;
    AsyncStorage.setItem(
      LS_KEY,
      JSON.stringify({ schedule, employees, showColors, appTheme, vibrateOnTap })
    ).catch(() => {});
  }, [schedule, employees, showColors, appTheme, vibrateOnTap]);

  const monthKey = `${year}-${month}`;
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDay(year, month);

  const getShift = useCallback(
    (emp: string, d: number): string | null => schedule[monthKey]?.[emp]?.[d] ?? null,
    [schedule, monthKey]
  );

  const setShift = useCallback(
    (emp: string, d: number, val: string | null) => {
      setSchedule((p) => ({
        ...p,
        [monthKey]: { ...p[monthKey], [emp]: { ...(p[monthKey]?.[emp] || {}), [d]: val } },
      }));
    },
    [monthKey]
  );

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear((y) => y - 1); }
    else { setMonth((m) => m - 1); }
  };
  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear((y) => y + 1); }
    else { setMonth((m) => m + 1); }
  };

  const addEmployee = (name: string): string => {
    const n = name.trim().toUpperCase();
    if (!n) return "Enter a name first.";
    if (employees.indexOf(n) !== -1) return "Already in the list.";
    setEmployees((p) => [...p, n]);
    return "";
  };

  const removeEmployee = (name: string) => {
    setEmployees((p) => p.filter((x) => x !== name));
  };

  const clearMonth = () => {
    setSchedule((p) => ({ ...p, [monthKey]: {} }));
  };

  const autoGenerate = () => {
    const gen: Record<string, Record<number, string | null>> = {};
    const abc = SHIFT_DEFS.filter((s) => !NON_WORKING.has(s.label) && s.label !== "OT" && s.label !== "G");
    employees.forEach((emp, ei) => {
      gen[emp] = {};
      for (let d = 1; d <= daysInMonth; d++) {
        const dow = new Date(year, month, d).getDay();
        gen[emp][d] = dow === 0 || dow === 6 ? null : abc[(ei + Math.floor((d - 1) / 3)) % 3].label;
      }
    });
    setSchedule((p) => ({ ...p, [monthKey]: gen }));
  };

  const applyBulk = (from: number, to: number, shift: string, target: string): string => {
    const f = clamp(from, 1, daysInMonth);
    const t = clamp(to, f, daysInMonth);
    const val = shift === "off" ? null : shift;
    const targets = target === "all" ? employees : [target];
    setSchedule((p) => {
      const mo = { ...(p[monthKey] || {}) };
      targets.forEach((emp) => {
        mo[emp] = { ...(mo[emp] || {}) };
        for (let d = f; d <= t; d++) mo[emp][d] = val;
      });
      return { ...p, [monthKey]: mo };
    });
    const who = target === "all" ? "all employees" : target;
    return `"${shift === "off" ? "Off" : shift}" applied to ${who}, days ${f}–${t}`;
  };

  const getCounts = useCallback(
    (emp: string): ShiftCounts => {
      const row: ShiftCounts = { off: 0, total: 0 };
      SHIFT_DEFS.forEach((sd) => { row[sd.label] = 0; });
      for (let d = 1; d <= daysInMonth; d++) {
        const s = getShift(emp, d);
        const dow = new Date(year, month, d).getDay();
        if (s) {
          row[s] = (row[s] || 0) + 1;
          if (!NON_WORKING.has(s)) row.total++;
        } else if (dow !== 0 && dow !== 6) {
          row.off++;
        }
      }
      return row;
    },
    [schedule, monthKey, daysInMonth, year, month, getShift]
  );

  const getShiftDefs = () => appTheme === "light" ? SHIFT_DEFS_LIGHT : SHIFT_DEFS;
  const getDaysArray = () => Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const restoreData = (data: { schedule?: ScheduleData; employees?: string[]; showColors?: boolean; appTheme?: "dark" | "light" }) => {
    if (data.schedule) setSchedule(data.schedule);
    if (Array.isArray(data.employees) && data.employees.length) setEmployees(data.employees);
    if (typeof data.showColors === "boolean") setShowColors(data.showColors);
    if (data.appTheme === "dark" || data.appTheme === "light") setAppTheme(data.appTheme);
  };

  return (
    <SchedulerContext.Provider
      value={{
        year, month, employees, schedule, showColors, appTheme, vibrateOnTap,
        daysInMonth, firstDay, monthKey,
        getShift, setShift, setYear, setMonth, prevMonth, nextMonth,
        addEmployee, removeEmployee, setShowColors, setAppTheme, setVibrateOnTap,
        clearMonth, autoGenerate, applyBulk, getCounts, getShiftDefs, getDaysArray,
        restoreData,
      }}
    >
      {children}
    </SchedulerContext.Provider>
  );
}

export function useScheduler() {
  const ctx = useContext(SchedulerContext);
  if (!ctx) throw new Error("useScheduler must be used within SchedulerProvider");
  return ctx;
}
