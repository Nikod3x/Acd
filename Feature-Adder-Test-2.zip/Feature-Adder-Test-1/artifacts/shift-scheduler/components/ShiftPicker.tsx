import React from "react";
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SHIFT_DEFS, SHIFT_DEFS_LIGHT } from "@/context/SchedulerContext";
import { useColors } from "@/hooks/useColors";

interface Props {
  visible: boolean;
  onClose: () => void;
  onSelect: (shift: string | null) => void;
  isDark: boolean;
  employeeName?: string;
  day?: number;
}

export function ShiftPicker({
  visible,
  onClose,
  onSelect,
  isDark,
  employeeName,
  day,
}: Props) {
  const colors = useColors();
  const defs = isDark ? SHIFT_DEFS : SHIFT_DEFS_LIGHT;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <Pressable style={styles.overlay} onPress={onClose}>
        <View
          style={[
            styles.panel,
            {
              backgroundColor: isDark ? "#0d0d1a" : "#ffffff",
              borderColor: isDark ? "#2a2a5a" : "#d4d8ec",
            },
          ]}
        >
          {employeeName && day && (
            <Text
              style={[
                styles.title,
                { color: isDark ? "#9090bb" : "#6a708a" },
              ]}
            >
              {employeeName} · Day {day}
            </Text>
          )}
          <ScrollView showsVerticalScrollIndicator={false}>
            <Pressable
              onPress={() => onSelect(null)}
              style={[
                styles.option,
                {
                  backgroundColor: isDark ? "#0b0b18" : "#f4f5fa",
                  borderColor: isDark ? "#22223a" : "#e0e4f2",
                },
              ]}
            >
              <Text
                style={[
                  styles.optionLabel,
                  { color: isDark ? "#666688" : "#8088a0" },
                ]}
              >
                — Off / Clear
              </Text>
            </Pressable>
            {defs.map((sd) => (
              <Pressable
                key={sd.label}
                onPress={() => onSelect(sd.label)}
                style={[
                  styles.option,
                  {
                    backgroundColor: sd.bg,
                    borderColor: sd.border + "66",
                  },
                ]}
              >
                <View style={styles.optionRow}>
                  <Text
                    style={[
                      styles.optionLabel,
                      { color: sd.text, fontWeight: "800" as const },
                    ]}
                  >
                    {sd.label}
                  </Text>
                  <Text style={[styles.optionFull, { color: sd.text + "bb" }]}>
                    {sd.full}
                  </Text>
                </View>
              </Pressable>
            ))}
          </ScrollView>
          <Pressable onPress={onClose} style={styles.closeBtn}>
            <Text style={{ color: isDark ? "#555566" : "#9098b0", fontSize: 11 }}>
              ✕ close
            </Text>
          </Pressable>
        </View>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.75)",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  panel: {
    width: "100%",
    maxWidth: 340,
    borderRadius: 14,
    borderWidth: 1,
    padding: 12,
    maxHeight: 480,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.9,
    shadowRadius: 30,
    elevation: 30,
  },
  title: {
    fontSize: 10,
    fontWeight: "600" as const,
    letterSpacing: 1.5,
    textTransform: "uppercase",
    marginBottom: 10,
    paddingHorizontal: 4,
  },
  option: {
    borderRadius: 8,
    padding: 11,
    marginBottom: 6,
    borderWidth: 1,
  },
  optionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  optionLabel: {
    fontSize: 13,
    letterSpacing: 0.5,
  },
  optionFull: {
    fontSize: 12,
  },
  closeBtn: {
    alignItems: "flex-end",
    paddingTop: 6,
    paddingHorizontal: 4,
  },
});
