import { Feather } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

const IG_URL = "https://www.instagram.com/anthreast_00?igsh=MW4zeGswZXpsenRsMQ==";
const IG_HANDLE = "@anthreast_00";

export function InstagramPopup() {
  const [visible, setVisible] = useState(true);
  const slideX = useRef(new Animated.Value(-220)).current;
  const pulse = useRef(new Animated.Value(0.5)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Slide in from left after short delay
    setTimeout(() => {
      Animated.parallel([
        Animated.spring(slideX, {
          toValue: 0,
          tension: 60,
          friction: 9,
          useNativeDriver: false,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 350,
          useNativeDriver: false,
        }),
      ]).start();
    }, 700);

    // Pulsing glow loop
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1400,
          useNativeDriver: false,
        }),
        Animated.timing(pulse, {
          toValue: 0.3,
          duration: 1400,
          useNativeDriver: false,
        }),
      ])
    );
    pulseLoop.start();
    return () => pulseLoop.stop();
  }, []);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(slideX, {
        toValue: -220,
        duration: 250,
        useNativeDriver: false,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 220,
        useNativeDriver: false,
      }),
    ]).start(() => setVisible(false));
  };

  const handleOpen = () => {
    Linking.openURL(IG_URL).catch(() => {});
  };

  if (!visible) return null;

  const glowOpacity = pulse.interpolate({
    inputRange: [0, 1],
    outputRange: [0.25, 0.85],
  });
  const glowRadius = pulse.interpolate({
    inputRange: [0, 1],
    outputRange: [6, 16],
  });

  return (
    <Animated.View
      style={[
        styles.wrapper,
        { transform: [{ translateX: slideX }], opacity },
      ]}
      pointerEvents="box-none"
    >
      {/* Pulsing glow ring */}
      <Animated.View
        style={[
          styles.glowRing,
          {
            opacity: glowOpacity,
            shadowRadius: glowRadius,
          },
        ]}
      />

      {/* Pill */}
      <View style={styles.pill}>
        <Pressable onPress={handleOpen} style={styles.pillContent}>
          <View style={styles.igIconWrap}>
            <Feather name="instagram" size={14} color="#fff" />
          </View>
          <Text style={styles.handle} numberOfLines={1}>{IG_HANDLE}</Text>
        </Pressable>
        <Pressable onPress={handleClose} style={styles.closeBtn}>
          <Text style={styles.closeX}>✕</Text>
        </Pressable>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    top: Platform.OS === "web" ? 76 : 56,
    left: 12,
    zIndex: 9999,
  },
  glowRing: {
    position: "absolute",
    top: -4,
    left: -4,
    right: -4,
    bottom: -4,
    borderRadius: 30,
    backgroundColor: "transparent",
    shadowColor: "#e040fb",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 10,
    elevation: 10,
    borderWidth: 1.5,
    borderColor: "#c724c7",
  },
  pill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1a0a22",
    borderRadius: 24,
    borderWidth: 1,
    borderColor: "#c724c7",
    paddingLeft: 6,
    paddingRight: 6,
    paddingVertical: 5,
    gap: 2,
    shadowColor: "#e040fb",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.7,
    shadowRadius: 8,
    elevation: 8,
  },
  pillContent: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingRight: 4,
  },
  igIconWrap: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "#c724c7",
    alignItems: "center",
    justifyContent: "center",
  },
  handle: {
    color: "#e89cf7",
    fontSize: 11,
    fontWeight: "700" as const,
    letterSpacing: 0.2,
  },
  closeBtn: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: "#2d1040",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 2,
  },
  closeX: {
    color: "#a060c0",
    fontSize: 9,
    fontWeight: "700" as const,
  },
});
