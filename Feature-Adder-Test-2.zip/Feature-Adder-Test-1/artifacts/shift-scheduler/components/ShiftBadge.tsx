import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { ShiftDef } from "@/context/SchedulerContext";

interface Props {
  shiftDef: ShiftDef | null;
  isWeekend?: boolean;
  isToday?: boolean;
  size?: "sm" | "md" | "lg";
  showColors?: boolean;
  isDark?: boolean;
}

export function ShiftBadge({
  shiftDef,
  isWeekend,
  isToday,
  size = "md",
  showColors = true,
  isDark = true,
}: Props) {
  const fontSize = size === "sm" ? 9 : size === "lg" ? 14 : 11;
  const paddingH = size === "sm" ? 5 : size === "lg" ? 10 : 7;
  const paddingV = size === "sm" ? 2 : size === "lg" ? 5 : 3;
  const borderRadius = size === "sm" ? 4 : 6;

  if (!shiftDef) {
    if (isWeekend) {
      return (
        <View
          style={[
            styles.badge,
            {
              backgroundColor: "transparent",
              borderWidth: 0,
              paddingHorizontal: paddingH,
              paddingVertical: paddingV,
              borderRadius,
            },
          ]}
        >
          <Text
            style={{
              fontSize,
              color: isDark ? "#1a1a28" : "#b0b5c8",
              fontWeight: "600" as const,
            }}
          >
            •
          </Text>
        </View>
      );
    }
    return (
      <View
        style={[
          styles.badge,
          {
            backgroundColor: "transparent",
            borderWidth: 0,
            paddingHorizontal: paddingH,
            paddingVertical: paddingV,
            borderRadius,
          },
        ]}
      >
        <Text
          style={{
            fontSize,
            color: isDark ? "#333344" : "#c0c4d6",
            fontWeight: "400" as const,
          }}
        >
          –
        </Text>
      </View>
    );
  }

  if (!showColors) {
    return (
      <View
        style={[
          styles.badge,
          {
            backgroundColor: "transparent",
            borderWidth: 1,
            borderColor: isDark ? "#333" : "#ddd",
            paddingHorizontal: paddingH,
            paddingVertical: paddingV,
            borderRadius,
          },
        ]}
      >
        <Text
          style={{
            fontSize,
            color: isDark ? "#ccccdd" : "#333",
            fontWeight: "800" as const,
          }}
        >
          {shiftDef.label}
        </Text>
      </View>
    );
  }

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: shiftDef.bg,
          borderWidth: 1,
          borderColor: shiftDef.border + "88",
          paddingHorizontal: paddingH,
          paddingVertical: paddingV,
          borderRadius,
        },
      ]}
    >
      <Text
        style={{
          fontSize,
          color: shiftDef.text,
          fontWeight: "800" as const,
          letterSpacing: 0.3,
        }}
      >
        {shiftDef.label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignItems: "center",
    justifyContent: "center",
    minWidth: 28,
  },
});
