import * as Haptics from "expo-haptics";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import * as DocumentPicker from "expo-document-picker";
import React, { useRef, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { MONTH_NAMES, useScheduler } from "@/context/SchedulerContext";
import { Toast } from "@/components/Toast";

export default function SettingsScreen() {
  const {
    year,
    month,
    employees,
    schedule,
    showColors,
    appTheme,
    vibrateOnTap,
    addEmployee,
    removeEmployee,
    setShowColors,
    setAppTheme,
    setVibrateOnTap,
    restoreData,
  } = useScheduler();

  const insets = useSafeAreaInsets();
  const isDark = appTheme === "dark";
  const [newEmp, setNewEmp] = useState("");
  const [toast, setToast] = useState("");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const bg = isDark ? "#080810" : "#f2f3fa";
  const panelBg = isDark ? "#0d0d1a" : "#ffffff";
  const borderColor = isDark ? "#1a1a2e" : "#d4d8ec";
  const textColor = isDark ? "#e0e0f0" : "#1a1a2e";
  const dimColor = isDark ? "#666688" : "#6a708a";
  const navBg = isDark ? "#0f0f1a" : "#eceff8";
  const navBrd = isDark ? "#1e1e30" : "#c8cce0";
  const topPad = Platform.OS === "web" ? insets.top + 67 : insets.top;

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 3000);
  };

  const handleAdd = () => {
    const err = addEmployee(newEmp);
    if (err) { showToast(err); return; }
    showToast(`Added ${newEmp.trim().toUpperCase()}`);
    setNewEmp("");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleRemove = (emp: string) => {
    Alert.alert("Remove Employee", `Remove ${emp}? Their schedule data is kept.`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => {
          removeEmployee(emp);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          showToast(`Removed ${emp}`);
        },
      },
    ]);
  };

  const handleBackup = async () => {
    try {
      const data = JSON.stringify({ schedule, employees, showColors, appTheme }, null, 2);
      const filename = `ShiftScheduler-Backup-${MONTH_NAMES[month]}-${year}.json`;
      if (Platform.OS === "web" && typeof document !== "undefined") {
        const blob = new Blob([data], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast("Backup downloaded!");
      } else {
        const fileUri = (FileSystem.cacheDirectory ?? FileSystem.documentDirectory ?? "") + filename;
        await FileSystem.writeAsStringAsync(fileUri, data, { encoding: FileSystem.EncodingType.UTF8 });
        await Sharing.shareAsync(fileUri, { mimeType: "application/json", dialogTitle: "Save Backup File" });
        showToast("Backup ready — choose where to save it!");
      }
    } catch {
      showToast("Backup failed. Try again.");
    }
  };

  const handleRestorePress = async () => {
    if (Platform.OS === "web" && typeof document !== "undefined") {
      if (!fileInputRef.current) {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = "application/json,.json";
        input.onchange = (e: any) => {
          const file = e.target?.files?.[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = (ev) => {
            try {
              const parsed = JSON.parse(ev.target?.result as string);
              restoreData(parsed);
              showToast("Data restored!");
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            } catch {
              showToast("Invalid backup file.");
            }
          };
          reader.readAsText(file);
        };
        (fileInputRef as any).current = input;
      }
      fileInputRef.current!.click();
    } else {
      try {
        const result = await DocumentPicker.getDocumentAsync({
          type: ["application/json", "*/*"],
          copyToCacheDirectory: true,
        });
        if (result.canceled) return;
        const content = await FileSystem.readAsStringAsync(result.assets[0].uri, {
          encoding: FileSystem.EncodingType.UTF8,
        });
        const parsed = JSON.parse(content);
        restoreData(parsed);
        showToast("Data restored successfully!");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch {
        showToast("Could not read file. Please pick a valid backup.");
      }
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View
        style={[styles.header, { backgroundColor: navBg, borderBottomColor: navBrd, paddingTop: topPad + 8 }]}
      >
        <Text style={[styles.headerTitle, { color: isDark ? "#fff" : "#0a0a1a" }]}>Settings</Text>
        <Text style={[styles.headerSub, { color: dimColor }]}>
          {MONTH_NAMES[month]} {year} · {employees.length} employees
        </Text>
      </View>

      {toast ? (
        <View style={{ paddingHorizontal: 14, paddingTop: 8 }}>
          <Toast message={toast} isDark={isDark} />
        </View>
      ) : null}

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        {/* Display settings */}
        <View style={[styles.section, { backgroundColor: panelBg, borderColor }]}>
          <Text style={[styles.sectionTitle, { color: dimColor }]}>DISPLAY</Text>

          <View style={styles.settingRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.settingLabel, { color: textColor }]}>Color Mode</Text>
              <Text style={[styles.settingDesc, { color: dimColor }]}>Colorful cells vs monochrome</Text>
            </View>
            <Pressable
              onPress={() => { setShowColors(!showColors); Haptics.selectionAsync(); }}
              style={[styles.toggle, { backgroundColor: showColors ? "#a855f7" : (isDark ? "#1a1a2e" : "#e0e4f2") }]}
            >
              <View style={[styles.toggleThumb, { transform: [{ translateX: showColors ? 20 : 2 }] }]} />
            </Pressable>
          </View>

          <View style={[styles.divider, { backgroundColor: borderColor }]} />

          <View style={styles.settingRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.settingLabel, { color: textColor }]}>App Theme</Text>
              <Text style={[styles.settingDesc, { color: dimColor }]}>Dark or light background</Text>
            </View>
            <Pressable
              onPress={() => { setAppTheme(appTheme === "dark" ? "light" : "dark"); Haptics.selectionAsync(); }}
              style={[styles.themeToggle, { backgroundColor: isDark ? "#0d2137" : "#dbeeff", borderColor: "#3b9ede" }]}
            >
              <Text style={{ fontSize: 15 }}>{appTheme === "dark" ? "🌑" : "☀"}</Text>
              <Text style={{ color: "#3b9ede", fontSize: 11, fontWeight: "600" as const }}>
                {appTheme === "dark" ? "Dark" : "Light"}
              </Text>
            </Pressable>
          </View>

          <View style={[styles.divider, { backgroundColor: borderColor }]} />

          <View style={styles.settingRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.settingLabel, { color: textColor }]}>Vibration</Text>
              <Text style={[styles.settingDesc, { color: dimColor }]}>Vibrate when tapping a shift cell</Text>
            </View>
            <Pressable
              onPress={() => { const next = !vibrateOnTap; setVibrateOnTap(next); if (next) Haptics.selectionAsync(); }}
              style={[styles.toggle, { backgroundColor: vibrateOnTap ? "#14b8a6" : (isDark ? "#1a1a2e" : "#e0e4f2") }]}
            >
              <View style={[styles.toggleThumb, { transform: [{ translateX: vibrateOnTap ? 20 : 2 }] }]} />
            </Pressable>
          </View>
        </View>

        {/* Data management */}
        <View style={[styles.section, { backgroundColor: panelBg, borderColor }]}>
          <Text style={[styles.sectionTitle, { color: dimColor }]}>DATA</Text>

          <View style={styles.dataRow}>
            <View style={{ flex: 1, marginRight: 8 }}>
              <Text style={[styles.settingLabel, { color: textColor }]}>Backup</Text>
              <Text style={[styles.settingDesc, { color: dimColor }]}>Download all schedule data as JSON</Text>
            </View>
            <Pressable
              onPress={handleBackup}
              style={[styles.dataBtn, { backgroundColor: isDark ? "#0d2137" : "#dbeeff", borderColor: "#3b9ede" }]}
            >
              <Text style={{ color: "#3b9ede", fontSize: 12, fontWeight: "700" as const }}>⬇ Backup</Text>
            </Pressable>
          </View>

          <View style={[styles.divider, { backgroundColor: borderColor }]} />

          <View style={styles.dataRow}>
            <View style={{ flex: 1, marginRight: 8 }}>
              <Text style={[styles.settingLabel, { color: textColor }]}>Restore</Text>
              <Text style={[styles.settingDesc, { color: dimColor }]}>Load data from a backup JSON file</Text>
            </View>
            <Pressable
              onPress={handleRestorePress}
              style={[styles.dataBtn, { backgroundColor: isDark ? "#1a2b0d" : "#e0f5cc", borderColor: "#6bbf3b" }]}
            >
              <Text style={{ color: "#6bbf3b", fontSize: 12, fontWeight: "700" as const }}>⬆ Restore</Text>
            </Pressable>
          </View>
        </View>

        {/* Employees */}
        <View style={[styles.section, { backgroundColor: panelBg, borderColor }]}>
          <Text style={[styles.sectionTitle, { color: dimColor }]}>EMPLOYEES</Text>
          <View style={styles.addRow}>
            <TextInput
              value={newEmp}
              onChangeText={setNewEmp}
              placeholder="Employee name"
              placeholderTextColor={dimColor}
              style={[
                styles.textInput,
                { backgroundColor: isDark ? "#080810" : "#f4f5fa", borderColor, color: textColor },
              ]}
              autoCapitalize="characters"
              returnKeyType="done"
              onSubmitEditing={handleAdd}
            />
            <Pressable
              onPress={handleAdd}
              style={[styles.addBtn, { backgroundColor: isDark ? "#0d2137" : "#dbeeff", borderColor: "#3b9ede" }]}
            >
              <Text style={{ color: "#3b9ede", fontSize: 14, fontWeight: "700" as const }}>+</Text>
            </Pressable>
          </View>

          <View style={{ marginTop: 8 }}>
            {employees.map((emp, i) => (
              <View key={emp}>
                {i > 0 && <View style={[styles.divider, { backgroundColor: isDark ? "#111" : "#eee" }]} />}
                <View style={styles.empRow}>
                  <Text style={[styles.empNum, { color: dimColor }]}>{i + 1}.</Text>
                  <Text style={[styles.empName, { color: textColor }]} numberOfLines={1}>{emp}</Text>
                  <Pressable
                    onPress={() => handleRemove(emp)}
                    style={[styles.removeBtn, { borderColor: isDark ? "#2d0d0d" : "#ffdddd" }]}
                  >
                    <Text style={{ color: "#ef4444", fontSize: 12 }}>✕</Text>
                  </Pressable>
                </View>
              </View>
            ))}
            {employees.length === 0 && (
              <Text style={{ color: dimColor, fontSize: 12, textAlign: "center", paddingVertical: 20 }}>
                No employees yet. Add one above.
              </Text>
            )}
          </View>
        </View>

        {/* Shift Legend */}
        <View style={[styles.section, { backgroundColor: panelBg, borderColor }]}>
          <Text style={[styles.sectionTitle, { color: dimColor }]}>SHIFT TYPES</Text>
          {[
            { label: "A",   full: "A Shift",  color: "#3b9ede" },
            { label: "B",   full: "B Shift",  color: "#6bbf3b" },
            { label: "C",   full: "C Shift",  color: "#e0912a" },
            { label: "G",   full: "G Shift",  color: "#ff2d78" },
            { label: "W/O", full: "Week Off", color: "#a855f7" },
            { label: "L",   full: "Leave",    color: "#ef4444" },
            { label: "OT",  full: "Overtime", color: "#14b8a6" },
            { label: "ABS", full: "Absent",   color: "#eab308" },
          ].map((s, i) => (
            <View key={s.label}>
              {i > 0 && <View style={[styles.divider, { backgroundColor: isDark ? "#111" : "#eee" }]} />}
              <View style={styles.shiftRow}>
                <View style={[styles.shiftDot, { backgroundColor: s.color + "22", borderColor: s.color }]}>
                  <Text style={{ color: s.color, fontSize: 9, fontWeight: "800" as const }}>{s.label}</Text>
                </View>
                <Text style={[styles.shiftName, { color: textColor }]}>{s.full}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={{ height: Platform.OS === "web" ? 100 : 50 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 14, paddingBottom: 14, borderBottomWidth: 1 },
  headerTitle: { fontSize: 22, fontWeight: "900" as const, letterSpacing: -0.5, marginBottom: 2 },
  headerSub: { fontSize: 11 },
  section: { margin: 14, marginBottom: 0, padding: 16, borderRadius: 12, borderWidth: 1 },
  sectionTitle: { fontSize: 9, letterSpacing: 3, fontWeight: "700" as const, marginBottom: 14 },
  settingRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10 },
  settingLabel: { fontSize: 14, fontWeight: "600" as const, marginBottom: 2 },
  settingDesc: { fontSize: 11 },
  toggle: { width: 44, height: 24, borderRadius: 12, justifyContent: "center", position: "relative" },
  toggleThumb: {
    width: 20, height: 20, borderRadius: 10, backgroundColor: "#fff",
    position: "absolute",
    shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.3, shadowRadius: 2, elevation: 2,
  },
  themeToggle: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1,
  },
  divider: { height: 1, marginVertical: 2 },
  dataRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10 },
  dataBtn: {
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1,
    alignItems: "center", justifyContent: "center", minWidth: 90,
  },
  addRow: { flexDirection: "row", gap: 8 },
  textInput: {
    flex: 1, height: 40, borderRadius: 8, borderWidth: 1,
    paddingHorizontal: 12, fontSize: 12,
  },
  addBtn: {
    width: 40, height: 40, borderRadius: 8, borderWidth: 1,
    alignItems: "center", justifyContent: "center",
  },
  empRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10, gap: 8 },
  empNum: { fontSize: 10, minWidth: 20 },
  empName: { flex: 1, fontSize: 13, fontWeight: "600" as const },
  removeBtn: {
    width: 28, height: 28, borderRadius: 6, borderWidth: 1,
    alignItems: "center", justifyContent: "center",
  },
  shiftRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 9 },
  shiftDot: {
    width: 32, height: 22, borderRadius: 5, borderWidth: 1,
    alignItems: "center", justifyContent: "center",
  },
  shiftName: { fontSize: 13, fontWeight: "500" as const },
});
