import * as Haptics from "expo-haptics";
import React, { useCallback, useRef, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  DAY_SHORT,
  MONTH_NAMES,
  SHIFT_DEFS,
  useScheduler,
} from "@/context/SchedulerContext";
import { ShiftPicker } from "@/components/ShiftPicker";
import { Toast } from "@/components/Toast";

export default function TableScreen() {
  const {
    year,
    month,
    employees,
    showColors,
    appTheme,
    vibrateOnTap,
    daysInMonth,
    getShift,
    setShift,
    prevMonth,
    nextMonth,
    getCounts,
    getShiftDefs,
    getDaysArray,
    clearMonth,
    autoGenerate,
    applyBulk,
  } = useScheduler();

  const insets = useSafeAreaInsets();
  const isDark = appTheme === "dark";
  const defs = getShiftDefs();
  const days = getDaysArray();
  const today = new Date();

  const [pickerEmp, setPickerEmp] = useState<string | null>(null);
  const [pickerDay, setPickerDay] = useState<number>(0);
  const [toast, setToast] = useState("");
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [bFrom, setBFrom] = useState(1);
  const [bTo, setBTo] = useState(7);
  const [bShift, setBShift] = useState("A");
  const [bTarget, setBTarget] = useState("all");
  const [showBulk, setShowBulk] = useState(false);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 3000);
  }, []);

  const triggerVibrate = () => {
    if (vibrateOnTap && typeof navigator !== "undefined" && (navigator as any).vibrate) {
      (navigator as any).vibrate(50);
    }
  };

  const openPicker = (emp: string, day: number) => {
    if (vibrateOnTap) Haptics.selectionAsync();
    triggerVibrate();
    setPickerEmp(emp);
    setPickerDay(day);
  };

  const handleShiftSelect = (shift: string | null) => {
    if (pickerEmp && pickerDay) {
      setShift(pickerEmp, pickerDay, shift);
      if (vibrateOnTap) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    setPickerEmp(null);
    setPickerDay(0);
  };

  const handleAutoGenerate = () => {
    autoGenerate();
    if (vibrateOnTap) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    showToast("Schedule generated!");
  };

  const handleClear = () => {
    clearMonth();
    showToast("Schedule cleared.");
  };

  const handleApplyBulk = () => {
    const msg = applyBulk(bFrom, bTo, bShift, bTarget);
    showToast(msg);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowBulk(false);
  };

  const shiftDef = (lbl: string | null) =>
    lbl ? defs.find((s) => s.label === lbl) || null : null;

  const bg = isDark ? "#080810" : "#f2f3fa";
  const panelBg = isDark ? "#0d0d1a" : "#ffffff";
  const borderColor = isDark ? "#1a1a2e" : "#d4d8ec";
  const textColor = isDark ? "#e0e0f0" : "#1a1a2e";
  const dimColor = isDark ? "#666688" : "#6a708a";
  const panel2 = isDark ? "#09091a" : "#eceff8";
  const navBg = isDark ? "#0f0f1a" : "#eceff8";
  const navBrd = isDark ? "#1e1e30" : "#c8cce0";

  const topPad = Platform.OS === "web" ? insets.top + 67 : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          { backgroundColor: navBg, borderBottomColor: navBrd, paddingTop: topPad + 8 },
        ]}
      >
        {/* Title row */}
        <View style={styles.titleRow}>
          <Text style={[styles.headerSub, { color: dimColor }]}>PERSONNEL SHIFT MANAGEMENT</Text>
          <Text style={[styles.headerTitle, { color: isDark ? "#fff" : "#0a0a1a" }]}>
            Shift Scheduler
          </Text>
        </View>

        {/* Month nav — own full-width row */}
        <View style={styles.navRow}>
          <Pressable
            onPress={prevMonth}
            style={[styles.navBtn, { backgroundColor: navBg, borderColor: navBrd }]}
          >
            <Text style={{ color: dimColor, fontSize: 20 }}>‹</Text>
          </Pressable>
          <View style={styles.navCenter}>
            <Text style={[styles.navMonth, { color: isDark ? "#fff" : "#0a0a1a" }]}>
              {MONTH_NAMES[month]}
            </Text>
            <Text style={[styles.navYear, { color: dimColor }]}>{year}</Text>
          </View>
          <Pressable
            onPress={nextMonth}
            style={[styles.navBtn, { backgroundColor: navBg, borderColor: navBrd }]}
          >
            <Text style={{ color: dimColor, fontSize: 20 }}>›</Text>
          </Pressable>
        </View>
      </View>

      {/* Toast */}
      {toast ? (
        <View style={{ paddingHorizontal: 14, paddingTop: 8 }}>
          <Toast message={toast} isDark={isDark} />
        </View>
      ) : null}

      {/* Action buttons */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ maxHeight: 54, flexShrink: 0 }}
        contentContainerStyle={styles.actionStrip}
      >
        <Pressable
          onPress={handleAutoGenerate}
          style={[styles.actionBtn, { borderColor: "#3b9ede", backgroundColor: isDark ? "#0d2137" : "#dbeeff" }]}
        >
          <Text style={{ color: "#3b9ede", fontSize: 11, fontWeight: "700" as const }}>⚡ Auto-Generate</Text>
        </Pressable>
        <Pressable
          onPress={handleClear}
          style={[styles.actionBtn, { borderColor: "#ef4444", backgroundColor: isDark ? "#2d0d0d" : "#ffdddd" }]}
        >
          <Text style={{ color: "#ef4444", fontSize: 11, fontWeight: "700" as const }}>✕ Clear</Text>
        </Pressable>
        <Pressable
          onPress={() => setShowBulk(v => !v)}
          style={[styles.actionBtn, { borderColor: "#6bbf3b", backgroundColor: isDark ? "#1a2b0d" : "#e0f5cc" }]}
        >
          <Text style={{ color: "#6bbf3b", fontSize: 11, fontWeight: "700" as const }}>📋 Bulk Assign</Text>
        </Pressable>
      </ScrollView>

      {/* Bulk Assign Panel */}
      {showBulk && (
        <View style={[styles.bulkPanel, { backgroundColor: panel2, borderColor }]}>
          <Text style={[styles.bulkTitle, { color: "#3b9ede" }]}>BULK ASSIGN</Text>
          <View style={styles.bulkRow}>
            <Text style={{ color: dimColor, fontSize: 11 }}>Day</Text>
            <Pressable onPress={() => setBFrom(Math.max(1, bFrom - 1))} style={[styles.numBtn, { borderColor }]}>
              <Text style={{ color: textColor }}>−</Text>
            </Pressable>
            <Text style={[styles.numVal, { color: textColor }]}>{bFrom}</Text>
            <Pressable onPress={() => setBFrom(Math.min(daysInMonth, bFrom + 1))} style={[styles.numBtn, { borderColor }]}>
              <Text style={{ color: textColor }}>+</Text>
            </Pressable>
            <Text style={{ color: dimColor, fontSize: 11 }}>to</Text>
            <Pressable onPress={() => setBTo(Math.max(bFrom, bTo - 1))} style={[styles.numBtn, { borderColor }]}>
              <Text style={{ color: textColor }}>−</Text>
            </Pressable>
            <Text style={[styles.numVal, { color: textColor }]}>{bTo}</Text>
            <Pressable onPress={() => setBTo(Math.min(daysInMonth, bTo + 1))} style={[styles.numBtn, { borderColor }]}>
              <Text style={{ color: textColor }}>+</Text>
            </Pressable>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
            <View style={{ flexDirection: "row", gap: 6, paddingVertical: 4 }}>
              {[...SHIFT_DEFS, { label: "off", full: "Off", bg: "transparent", border: "#888", text: "#aaa" }].map((sd) => (
                <Pressable
                  key={sd.label}
                  onPress={() => setBShift(sd.label)}
                  style={[
                    styles.shiftChip,
                    {
                      backgroundColor: bShift === sd.label ? sd.bg : "transparent",
                      borderColor: bShift === sd.label ? sd.border : (isDark ? "#333" : "#ccc"),
                    },
                  ]}
                >
                  <Text style={{ color: bShift === sd.label ? sd.text : dimColor, fontSize: 10, fontWeight: "800" as const }}>
                    {sd.label === "off" ? "Off" : sd.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
            <View style={{ flexDirection: "row", gap: 6 }}>
              {["all", ...employees].map((emp) => (
                <Pressable
                  key={emp}
                  onPress={() => setBTarget(emp)}
                  style={[
                    styles.empChip,
                    {
                      backgroundColor: bTarget === emp ? (isDark ? "#0d2137" : "#dbeeff") : "transparent",
                      borderColor: bTarget === emp ? "#3b9ede" : (isDark ? "#333" : "#ccc"),
                    },
                  ]}
                >
                  <Text style={{ color: bTarget === emp ? "#3b9ede" : dimColor, fontSize: 10, fontWeight: "600" as const }} numberOfLines={1}>
                    {emp === "all" ? "All Employees" : emp}
                  </Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>
          <Pressable
            onPress={handleApplyBulk}
            style={[styles.applyBtn, { backgroundColor: isDark ? "#1a2b0d" : "#e0f5cc", borderColor: "#6bbf3b" }]}
          >
            <Text style={{ color: "#6bbf3b", fontWeight: "700" as const, fontSize: 12 }}>✓ Apply</Text>
          </Pressable>
        </View>
      )}

      {/* Table */}
      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View>
            {/* Header row */}
            <View style={[styles.tableRow, { backgroundColor: isDark ? "#0e0e1c" : "#eceff8" }]}>
              <View style={[styles.empCell, { backgroundColor: isDark ? "#0a0a18" : "#eceff8", borderRightColor: borderColor, borderRightWidth: 1 }]}>
                <Text style={{ color: dimColor, fontSize: 9, fontWeight: "600" as const }}>EMPLOYEE</Text>
              </View>
              {days.map((d) => {
                const dow = new Date(year, month, d).getDay();
                const isWE = dow === 0 || dow === 6;
                const isTD = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
                return (
                  <View
                    key={d}
                    style={[
                      styles.dayHeadCell,
                      {
                        backgroundColor: isTD
                          ? (isDark ? "#1a1a4a" : "#dfe5ff")
                          : isWE
                          ? (isDark ? "#0a0a14" : "#e0e4f2")
                          : (isDark ? "#0e0e1c" : "#eceff8"),
                        borderBottomColor: borderColor,
                      },
                    ]}
                  >
                    <Text style={{ fontSize: 9, fontWeight: "600" as const, color: isTD ? (isDark ? "#7eb8f7" : "#1a23be") : isWE ? (isDark ? "#3a3a5a" : "#9095aa") : (isDark ? "#445566" : "#6a708a") }}>
                      {d}
                    </Text>
                    <Text style={{ fontSize: 6, color: isTD ? (isDark ? "#7eb8f7" : "#1a23be") : (isDark ? "#333355" : "#9095aa") }}>
                      {DAY_SHORT[dow]}
                    </Text>
                  </View>
                );
              })}
              {defs.map((sd) => (
                <View key={sd.label} style={[styles.sumHeadCell, { backgroundColor: showColors ? sd.bg : (isDark ? "#0a0a14" : "#e0e4f2"), borderLeftColor: borderColor }]}>
                  <Text style={{ fontSize: sd.label.length >= 3 ? 6 : 8, fontWeight: "800" as const, color: showColors ? sd.text : dimColor }}>
                    {sd.label}
                  </Text>
                </View>
              ))}
              <View style={[styles.sumHeadCell, { backgroundColor: isDark ? "#0a0a14" : "#e0e4f2", borderLeftColor: borderColor }]}>
                <Text style={{ fontSize: 8, color: dimColor, fontWeight: "600" as const }}>TOT</Text>
              </View>
            </View>

            {/* Employee rows */}
            {employees.map((emp, ri) => {
              const counts = getCounts(emp);
              return (
                <View
                  key={emp}
                  style={[
                    styles.tableRow,
                    { backgroundColor: ri % 2 === 0 ? (isDark ? "#09091a" : "#f4f6fc") : (isDark ? "#0b0b1e" : "#ffffff") },
                  ]}
                >
                  <View
                    style={[
                      styles.empCell,
                      {
                        backgroundColor: ri % 2 === 0 ? (isDark ? "#0d0d1e" : "#ffffff") : (isDark ? "#0f0f22" : "#eef1f9"),
                        borderRightColor: borderColor,
                        borderRightWidth: 1,
                      },
                    ]}
                  >
                    <Text style={{ color: dimColor, fontSize: 8, marginRight: 4 }}>{ri + 1}.</Text>
                    <Text style={{ color: isDark ? "#ccccdd" : "#2a2a3a", fontSize: 10, fontWeight: "700" as const }} numberOfLines={1}>
                      {emp}
                    </Text>
                  </View>
                  {days.map((d) => {
                    const s = getShift(emp, d);
                    const def = s ? defs.find((x) => x.label === s) : null;
                    const dow = new Date(year, month, d).getDay();
                    const isWE = dow === 0 || dow === 6;
                    const isTD = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
                    return (
                      <Pressable
                        key={d}
                        onPress={() => openPicker(emp, d)}
                        style={[
                          styles.dayCell,
                          {
                            backgroundColor: showColors
                              ? def ? def.bg : isWE ? (isDark ? "#07070e" : "#eceff8") : isTD ? (isDark ? "#10102a" : "#dfe5ff") : "transparent"
                              : isTD ? (isDark ? "#10102a" : "#dfe5ff") : "transparent",
                            borderLeftColor: isTD ? (isDark ? "#2a2a6a" : "#1a23be") : (isDark ? "#111" : "#e8ebf5"),
                            borderBottomColor: isDark ? "#111" : "#e8ebf5",
                          },
                        ]}
                      >
                        <Text
                          style={{
                            fontSize: 9,
                            fontWeight: "900" as const,
                            color: showColors
                              ? def ? def.text : isWE ? (isDark ? "#1a1a28" : "#b0b5c8") : (isDark ? "#2a2a3a" : "#c0c4d6")
                              : def ? (isDark ? "#ccccdd" : "#2a2a3a") : isWE ? (isDark ? "#1a1a28" : "#b0b5c8") : (isDark ? "#2a2a3a" : "#c0c4d6"),
                          }}
                        >
                          {s || (isWE ? "·" : "–")}
                        </Text>
                      </Pressable>
                    );
                  })}
                  {defs.map((sd) => (
                    <View
                      key={sd.label}
                      style={[
                        styles.sumCell,
                        {
                          backgroundColor: showColors && counts[sd.label] ? sd.bg : "transparent",
                          borderLeftColor: borderColor,
                        },
                      ]}
                    >
                      <Text
                        style={{
                          fontSize: 9,
                          fontWeight: "900" as const,
                          color: showColors && counts[sd.label]
                            ? sd.text
                            : counts[sd.label] ? (isDark ? "#ccccdd" : "#2a2a3a") : dimColor,
                        }}
                      >
                        {counts[sd.label] || "–"}
                      </Text>
                    </View>
                  ))}
                  <View style={[styles.sumCell, { borderLeftColor: borderColor }]}>
                    <Text style={{ fontSize: 10, fontWeight: "700" as const, color: dimColor }}>
                      {counts.total || 0}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        </ScrollView>

        {/* Legend */}
        <View style={[styles.legend, { borderTopColor: borderColor }]}>
          {defs.map((sd) => (
            <View key={sd.label} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: sd.bg, borderColor: sd.border }]} />
              <Text style={{ fontSize: 10, color: dimColor }}>{sd.full}</Text>
            </View>
          ))}
        </View>
        <View style={{ height: Platform.OS === "web" ? 100 : 40 }} />
      </ScrollView>

      <ShiftPicker
        visible={!!pickerEmp && !!pickerDay}
        onClose={() => { setPickerEmp(null); setPickerDay(0); }}
        onSelect={handleShiftSelect}
        isDark={isDark}
        employeeName={pickerEmp || ""}
        day={pickerDay}
      />
    </View>
  );
}

const CELL_W = 28;
const EMP_W = 150;
const SUM_W = 32;

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 14,
    paddingBottom: 10,
    borderBottomWidth: 1,
  },
  titleRow: {
    marginBottom: 10,
  },
  headerSub: {
    fontSize: 8,
    letterSpacing: 3,
    fontWeight: "700" as const,
    marginBottom: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "900" as const,
    letterSpacing: -0.5,
  },
  navRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
  },
  navCenter: {
    flex: 1,
    alignItems: "center",
  },
  navMonth: {
    fontSize: 16,
    fontWeight: "800" as const,
    letterSpacing: -0.3,
  },
  navYear: {
    fontSize: 10,
    marginTop: 1,
  },
  navBtn: {
    width: 38,
    height: 38,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  actionStrip: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    alignItems: "center",
  },
  actionBtn: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 7,
    borderWidth: 1,
  },
  bulkPanel: {
    marginHorizontal: 14,
    marginBottom: 10,
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
  },
  bulkTitle: {
    fontSize: 9,
    letterSpacing: 3,
    fontWeight: "700" as const,
    marginBottom: 10,
  },
  bulkRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 10,
  },
  numBtn: {
    width: 28,
    height: 28,
    borderRadius: 6,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  numVal: {
    fontSize: 14,
    fontWeight: "700" as const,
    minWidth: 22,
    textAlign: "center",
  },
  shiftChip: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 6,
    borderWidth: 1.5,
  },
  empChip: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 6,
    borderWidth: 1,
    maxWidth: 150,
  },
  applyBtn: {
    paddingVertical: 9,
    borderRadius: 7,
    borderWidth: 1,
    alignItems: "center",
  },
  tableRow: {
    flexDirection: "row",
    alignItems: "stretch",
  },
  empCell: {
    width: EMP_W,
    paddingHorizontal: 10,
    paddingVertical: 7,
    flexDirection: "row",
    alignItems: "center",
  },
  dayHeadCell: {
    width: CELL_W,
    minWidth: CELL_W,
    paddingVertical: 5,
    alignItems: "center",
    justifyContent: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#1a1a2e",
  },
  dayCell: {
    width: CELL_W,
    minWidth: CELL_W,
    paddingVertical: 6,
    alignItems: "center",
    justifyContent: "center",
    borderLeftWidth: 1,
    borderBottomWidth: 1,
  },
  sumHeadCell: {
    width: SUM_W,
    minWidth: SUM_W,
    paddingVertical: 5,
    alignItems: "center",
    justifyContent: "center",
    borderLeftWidth: 1,
    borderLeftColor: "#1a1a2e",
  },
  sumCell: {
    width: SUM_W,
    minWidth: SUM_W,
    paddingVertical: 7,
    alignItems: "center",
    justifyContent: "center",
    borderLeftWidth: 1,
  },
  legend: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    padding: 14,
    borderTopWidth: 1,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 3,
    borderWidth: 1.5,
  },
});
