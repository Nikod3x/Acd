import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  DAY_SHORT,
  MONTH_NAMES,
  useScheduler,
} from "@/context/SchedulerContext";
import { ShiftPicker } from "@/components/ShiftPicker";
import { Toast } from "@/components/Toast";

export default function CalendarScreen() {
  const {
    year,
    month,
    employees,
    showColors,
    appTheme,
    daysInMonth,
    firstDay,
    getShift,
    setShift,
    prevMonth,
    nextMonth,
    getCounts,
    getShiftDefs,
  } = useScheduler();

  const insets = useSafeAreaInsets();
  const isDark = appTheme === "dark";
  const defs = getShiftDefs();
  const today = new Date();

  const [selectedEmp, setSelectedEmp] = useState(employees[0] || "");
  const [pickerEmp, setPickerEmp] = useState<string | null>(null);
  const [pickerDay, setPickerDay] = useState<number>(0);
  const [toast, setToast] = useState("");

  const bg = isDark ? "#080810" : "#f2f3fa";
  const panelBg = isDark ? "#0d0d1a" : "#ffffff";
  const borderColor = isDark ? "#1a1a2e" : "#d4d8ec";
  const textColor = isDark ? "#e0e0f0" : "#1a1a2e";
  const dimColor = isDark ? "#666688" : "#6a708a";
  const navBg = isDark ? "#0f0f1a" : "#eceff8";
  const navBrd = isDark ? "#1e1e30" : "#c8cce0";

  const topPad = Platform.OS === "web" ? insets.top + 67 : insets.top;

  const calCells: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) calCells.push(null);
  for (let d = 1; d <= daysInMonth; d++) calCells.push(d);
  while (calCells.length % 7 !== 0) calCells.push(null);

  const openPicker = (emp: string, day: number) => {
    Haptics.selectionAsync();
    setPickerEmp(emp);
    setPickerDay(day);
  };

  const handleShiftSelect = (shift: string | null) => {
    if (pickerEmp && pickerDay) {
      setShift(pickerEmp, pickerDay, shift);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    setPickerEmp(null);
    setPickerDay(0);
  };

  const emp = selectedEmp || employees[0] || "";
  const counts = emp ? getCounts(emp) : { off: 0, total: 0 } as any;

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            backgroundColor: navBg,
            borderBottomColor: navBrd,
            paddingTop: topPad + 8,
          },
        ]}
      >
        <View style={styles.navRow}>
          <Pressable
            onPress={prevMonth}
            style={[styles.navBtn, { backgroundColor: navBg, borderColor: navBrd }]}
          >
            <Text style={{ color: dimColor, fontSize: 18 }}>‹</Text>
          </Pressable>
          <Text style={{ fontSize: 16, fontWeight: "800" as const, color: isDark ? "#fff" : "#0a0a1a" }}>
            {MONTH_NAMES[month]} {year}
          </Text>
          <Pressable
            onPress={nextMonth}
            style={[styles.navBtn, { backgroundColor: navBg, borderColor: navBrd }]}
          >
            <Text style={{ color: dimColor, fontSize: 18 }}>›</Text>
          </Pressable>
        </View>
      </View>

      {toast ? (
        <View style={{ paddingHorizontal: 14, paddingTop: 8 }}>
          <Toast message={toast} isDark={isDark} />
        </View>
      ) : null}

      {/* Employee selector */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ maxHeight: 52, flexShrink: 0 }}
        contentContainerStyle={styles.empStrip}
      >
        {employees.map((e) => (
          <Pressable
            key={e}
            onPress={() => setSelectedEmp(e)}
            style={[
              styles.empChip,
              {
                backgroundColor:
                  selectedEmp === e ? (isDark ? "#0d2137" : "#dbeeff") : "transparent",
                borderColor: selectedEmp === e ? "#3b9ede" : (isDark ? "#333" : "#ddd"),
              },
            ]}
          >
            <Text
              style={{
                color: selectedEmp === e ? "#3b9ede" : dimColor,
                fontSize: 11,
                fontWeight: "600" as const,
              }}
              numberOfLines={1}
            >
              {e}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Stats strip */}
      {emp ? (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ maxHeight: 42, flexShrink: 0 }}
          contentContainerStyle={{ flexDirection: "row", gap: 6, paddingHorizontal: 14, paddingVertical: 6 }}
        >
          {defs.map((sd) => (
            <View
              key={sd.label}
              style={[
                styles.statBadge,
                {
                  backgroundColor: sd.bg,
                  borderColor: sd.border + "66",
                },
              ]}
            >
              <Text style={{ fontSize: 9, fontWeight: "700" as const, color: sd.text }}>
                {sd.label}: {counts[sd.label] || 0}
              </Text>
            </View>
          ))}
          <View style={[styles.statBadge, { backgroundColor: isDark ? "#0d0d1a" : "#eceff8", borderColor: isDark ? "#3b9ede" : "#1565c0" }]}>
            <Text style={{ fontSize: 9, fontWeight: "700" as const, color: isDark ? "#3b9ede" : "#1565c0" }}>
              TOT: {counts.total || 0}
            </Text>
          </View>
        </ScrollView>
      ) : null}

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        {/* Day headers */}
        <View style={[styles.dayHeader, { borderBottomColor: borderColor }]}>
          {DAY_SHORT.map((d, i) => {
            const isWE = i === 0 || i === 6;
            return (
              <View key={d} style={styles.dayHeaderCell}>
                <Text
                  style={{
                    fontSize: 10,
                    fontWeight: "700" as const,
                    color: isWE
                      ? (isDark ? "#3a3a5a" : "#9095aa")
                      : dimColor,
                    letterSpacing: 0.5,
                  }}
                >
                  {d.toUpperCase()}
                </Text>
              </View>
            );
          })}
        </View>

        {/* Calendar grid */}
        <View style={styles.grid}>
          {calCells.map((day, idx) => {
            const col = idx % 7;
            const isWE = col === 0 || col === 6;
            const s = day && emp ? getShift(emp, day) : null;
            const def = s ? defs.find((x) => x.label === s) : null;
            const isTD =
              day === today.getDate() &&
              month === today.getMonth() &&
              year === today.getFullYear();

            if (!day) {
              return (
                <View
                  key={idx}
                  style={[
                    styles.cell,
                    { backgroundColor: "transparent" },
                  ]}
                />
              );
            }

            return (
              <Pressable
                key={idx}
                onPress={() => emp && openPicker(emp, day)}
                style={[
                  styles.cell,
                  {
                    backgroundColor:
                      showColors && def
                        ? def.bg
                        : isWE
                        ? (isDark ? "#07070e" : "#eceff8")
                        : isTD
                        ? (isDark ? "#10102a" : "#dfe5ff")
                        : (isDark ? "#0d0d1a" : "#ffffff"),
                    borderColor:
                      isTD
                        ? (isDark ? "#2a2a6a" : "#1a23be")
                        : showColors && def
                        ? def.border + "88"
                        : (isDark ? "#1a1a2e" : "#d4d8ec"),
                    borderWidth: isTD ? 1.5 : 1,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.dayNum,
                    {
                      color: isTD
                        ? (isDark ? "#fff" : "#1a23be")
                        : isWE
                        ? (isDark ? "#2a2a3a" : "#b0b5c8")
                        : (isDark ? "#555566" : "#8088a0"),
                    },
                  ]}
                >
                  {day}
                </Text>
                {s ? (
                  <Text
                    style={[
                      styles.shiftLabel,
                      {
                        color: def ? def.text : textColor,
                        fontSize: s.length >= 3 ? 11 : s.length >= 2 ? 13 : 17,
                      },
                    ]}
                  >
                    {s}
                  </Text>
                ) : (
                  <Text
                    style={[
                      styles.shiftLabel,
                      {
                        color: isWE
                          ? (isDark ? "#1a1a28" : "#b0b5c8")
                          : (isDark ? "#222233" : "#d4d8ec"),
                        fontSize: 10,
                      },
                    ]}
                  >
                    {isWE ? "OFF" : "—"}
                  </Text>
                )}
              </Pressable>
            );
          })}
        </View>

        {/* Legend */}
        <View style={[styles.legend, { borderTopColor: borderColor }]}>
          {defs.map((sd) => (
            <View key={sd.label} style={styles.legendItem}>
              <View
                style={[
                  styles.legendDot,
                  { backgroundColor: sd.bg, borderColor: sd.border },
                ]}
              />
              <Text style={{ fontSize: 10, color: dimColor }}>{sd.full}</Text>
            </View>
          ))}
        </View>
        <View style={{ height: Platform.OS === "web" ? 100 : 50 }} />
      </ScrollView>

      <ShiftPicker
        visible={!!pickerEmp && !!pickerDay}
        onClose={() => { setPickerEmp(null); setPickerDay(0); }}
        onSelect={handleShiftSelect}
        isDark={isDark}
        employeeName={pickerEmp || ""}
        day={pickerDay}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  navRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  navBtn: {
    width: 34,
    height: 34,
    borderRadius: 7,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  empStrip: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    alignItems: "center",
  },
  empChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    maxWidth: 180,
  },
  statBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 5,
    borderWidth: 1,
  },
  dayHeader: {
    flexDirection: "row",
    paddingHorizontal: 6,
    paddingVertical: 6,
    borderBottomWidth: 1,
  },
  dayHeaderCell: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 4,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    padding: 6,
    gap: 4,
  },
  cell: {
    width: `${(100 / 7) - 0.8}%` as any,
    aspectRatio: 0.85,
    borderRadius: 8,
    padding: 6,
    alignItems: "center",
    justifyContent: "space-between",
  },
  dayNum: {
    fontSize: 11,
    fontWeight: "700" as const,
    alignSelf: "flex-start",
  },
  shiftLabel: {
    fontWeight: "900" as const,
    letterSpacing: 0.3,
  },
  legend: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    padding: 14,
    borderTopWidth: 1,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 3,
    borderWidth: 1.5,
  },
});
