import * as FileSystem from "expo-file-system/legacy";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import React, { useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  clamp,
  DAY_SHORT,
  MONTH_NAMES,
  SHIFT_DEFS,
  useScheduler,
} from "@/context/SchedulerContext";
import { Toast } from "@/components/Toast";

// ─── Shift colour maps ───────────────────────────────────────────────────────
const SHIFT_PDF: Record<string, { bg_d: number[]; fg_d: number[]; bg_l: number[]; fg_l: number[] }> = {
  A:     { bg_d:[13,33,55],   fg_d:[59,158,222],  bg_l:[219,238,255], fg_l:[21,101,192] },
  B:     { bg_d:[26,43,13],   fg_d:[107,191,59],  bg_l:[224,245,204], fg_l:[46,125,30] },
  C:     { bg_d:[43,26,13],   fg_d:[224,145,42],  bg_l:[255,240,214], fg_l:[179,90,0] },
  G:     { bg_d:[45,13,26],   fg_d:[255,45,120],  bg_l:[255,208,224], fg_l:[180,0,70] },
  "W/O": { bg_d:[30,13,46],   fg_d:[168,85,247],  bg_l:[240,220,255], fg_l:[140,60,220] },
  L:     { bg_d:[45,13,13],   fg_d:[239,68,68],   bg_l:[255,220,220], fg_l:[185,28,28] },
  OT:    { bg_d:[13,45,45],   fg_d:[20,184,166],  bg_l:[210,245,240], fg_l:[14,120,110] },
  ABS:   { bg_d:[45,45,13],   fg_d:[234,179,8],   bg_l:[255,245,200], fg_l:[160,120,0] },
};

// ─── Build jsPDF HTML (runs inside WebView) ──────────────────────────────────
function buildJsPDFHtml(payload: string): string {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.3/jspdf.plugin.autotable.min.js"></script>
</head><body>
<script>
try {
  var payload = ${payload};
  var type = payload.type;
  var isDark = payload.isDark;
  var showColors = payload.showColors;
  var employees = payload.employees;
  var year = payload.year;
  var month = payload.month;
  var MONTH_NAMES = payload.MONTH_NAMES;
  var DAY_SHORT = payload.DAY_SHORT;
  var SHIFT_DEFS = payload.SHIFT_DEFS;
  var SHIFT_PDF = payload.SHIFT_PDF;
  var schedule = payload.schedule; // {emp: {day: shift}}
  var showColorsBool = showColors;

  function getShift(emp, d) {
    return (schedule[emp] && schedule[emp][d]) || null;
  }
  function sBg(lbl) { return SHIFT_PDF[lbl] ? (isDark ? SHIFT_PDF[lbl].bg_d : SHIFT_PDF[lbl].bg_l) : null; }
  function sFg(lbl) { return SHIFT_PDF[lbl] ? (isDark ? SHIFT_PDF[lbl].fg_d : SHIFT_PDF[lbl].fg_l) : null; }

  var NON_WORKING = ["W/O","L","ABS"];
  function getCounts(emp, days) {
    var c = {total:0};
    SHIFT_DEFS.forEach(function(sd){ c[sd.label]=0; });
    (days || Object.keys(schedule[emp]||{}).map(Number)).forEach(function(d){
      var s = getShift(emp,d);
      if(s){ c[s]=(c[s]||0)+1; if(NON_WORKING.indexOf(s)<0) c.total++; }
    });
    return c;
  }

  var { jsPDF } = window.jspdf;
  var doc, base64;

  if (type === "table") {
    var selDays = payload.selDays;
    var n = selDays.length;
    var f = selDays[0], t = selDays[selDays.length-1];
    var fmt = n <= 14 ? "a4" : "a3";
    var orient = n <= 7 ? "portrait" : "landscape";
    doc = new jsPDF({orientation:orient, unit:"mm", format:fmt});
    var pgW = doc.internal.pageSize.getWidth();
    var pgH = doc.internal.pageSize.getHeight();
    var fs = n<=7?10:n<=14?9:n<=21?8:7;

    if(isDark){doc.setFillColor(8,8,16);doc.rect(0,0,pgW,pgH,"F");}

    var label = f===t ? "Day "+f : "Days "+f+"\\u2013"+t;
    doc.setFont("helvetica","bold"); doc.setFontSize(14);
    doc.setTextColor.apply(doc, isDark?[210,215,230]:[20,20,20]);
    doc.text("Shift Schedule  |  "+MONTH_NAMES[month]+" "+year+"  ("+label+")", 12, 13);
    doc.setFont("helvetica","normal"); doc.setFontSize(8);
    doc.setTextColor.apply(doc, isDark?[80,85,110]:[130,130,130]);
    var today = new Date();
    doc.text(employees.length+" Personnel  \u00b7  Generated "+today.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}), 12, 19);
    doc.setTextColor(0);

    var sLabels = SHIFT_DEFS.map(function(sd){return sd.label;});
    var sCount = sLabels.length;
    var dayHdrFs = Math.max(fs-3,6);
    var empFs = Math.max(fs-2,7);

    var head = [["EMPLOYEE"].concat(selDays.map(function(d){
      return d+"\n"+DAY_SHORT[new Date(year,month,d).getDay()];
    })).concat(sLabels).concat(["TOT"])];

    var body = employees.map(function(emp){
      var counts = getCounts(emp, selDays);
      return [emp].concat(selDays.map(function(d){
        var s=getShift(emp,d);
        var isWE=[0,6].indexOf(new Date(year,month,d).getDay())>=0;
        return s||(isWE?"-":"");
      })).concat(sLabels.map(function(l){return counts[l]||0;})).concat([counts.total||0]);
    });

    var empW=44;
    function sumW(l){return l.length>=3?12:l.length>=2?10:8;}
    var totalSumW=sLabels.reduce(function(a,l){return a+sumW(l);},0)+sumW("TOT");
    var dayW=Math.min((pgW-24-empW-totalSumW)/n,40);

    var headFill=isDark?[13,13,28]:[20,20,38];
    var headText=isDark?[190,205,235]:[170,185,210];
    var headLine=isDark?[35,35,65]:[55,55,85];
    var bodyFill=isDark?[9,9,22]:[255,255,255];
    var bodyText2=isDark?[210,215,235]:[30,30,30];
    var altFill=isDark?[12,12,28]:[245,245,248];
    var empText=isDark?[230,235,255]:[25,25,25];
    var weCell=isDark?[7,7,18]:[220,220,220];
    var weText=isDark?[70,75,110]:[160,160,160];
    var totHead=isDark?[30,30,55]:[50,50,50];
    var totHeadTxt=isDark?[180,185,220]:[200,200,200];

    var colStyles = {0:{halign:"left",fontStyle:"bold",cellWidth:empW,textColor:empText,fontSize:empFs}};
    selDays.forEach(function(_,i){colStyles[i+1]={cellWidth:dayW};});
    sLabels.forEach(function(l,i){colStyles[n+1+i]={cellWidth:sumW(l),fontStyle:"bold",fontSize:6.5,cellPadding:1};});
    colStyles[n+1+sCount]={cellWidth:sumW("TOT"),fontStyle:"bold",fontSize:6.5,cellPadding:1};

    doc.autoTable({
      head:head, body:body, startY:24, margin:{left:12,right:12},
      styles:{fontSize:fs,cellPadding:2.2,halign:"center",valign:"middle",overflow:"hidden"},
      headStyles:{fillColor:headFill,textColor:headText,fontStyle:"bold",fontSize:fs,lineWidth:0.1,lineColor:headLine},
      bodyStyles:{fillColor:bodyFill,textColor:bodyText2},
      alternateRowStyles:{fillColor:altFill},
      columnStyles:colStyles,
      didParseCell:function(data){
        var ci=data.column.index, ri=data.row.index;
        var isSumCol=ci>n, isDayCol=ci>=1&&ci<=n;
        if(data.section==="head"){
          if(isSumCol){data.cell.styles.fontSize=6.5;data.cell.styles.cellPadding=1;}
          if(isDayCol){
            data.cell.styles.cellPadding=0.5;data.cell.styles.fontSize=dayHdrFs;
            var d=selDays[ci-1],dow=new Date(year,month,d).getDay(),isWE=dow===0||dow===6;
            if(isWE){data.cell.styles.fillColor=isDark?[18,18,35]:[200,200,200];data.cell.styles.textColor=isDark?[100,105,150]:[110,110,130];}
            data.cell.styles.fontStyle="bold";
          }
          var si=ci-n-1;
          if(showColorsBool&&si>=0&&si<sCount){var fg2=sFg(sLabels[si]);if(fg2){data.cell.styles.fillColor=fg2;data.cell.styles.textColor=[255,255,255];}}
          if(si===sCount){data.cell.styles.fillColor=totHead;data.cell.styles.textColor=totHeadTxt;}
        }
        if(data.section==="body"){
          if(isSumCol){data.cell.styles.fontSize=6.5;data.cell.styles.cellPadding=1;}
          if(isDayCol){
            data.cell.styles.cellPadding=0.5;
            if(dayW<10)data.cell.styles.fontSize=Math.min(fs,9);
            var d=selDays[ci-1],dow=new Date(year,month,d).getDay(),isWE=dow===0||dow===6;
            var s=getShift(employees[ri],d);
            if(showColorsBool){
              if(s&&sFg(s)){data.cell.styles.textColor=isDark?[8,8,16]:[255,255,255];}
              else if(isWE){data.cell.styles.fillColor=weCell;data.cell.styles.textColor=weText;}
            } else {
              if(s){data.cell.styles.fontStyle="bold";data.cell.styles.textColor=isDark?[220,225,240]:[20,20,20];}
              else if(isWE){data.cell.styles.fillColor=weCell;data.cell.styles.textColor=weText;}
            }
          }
          var si=ci-n-1;
          if(showColorsBool&&si>=0&&si<sCount){
            var bg2=sBg(sLabels[si]),fg2=sFg(sLabels[si]);
            if(bg2&&fg2){data.cell.styles.fillColor=bg2;data.cell.styles.textColor=fg2;data.cell.styles.fontStyle="bold";}
          }
        }
      },
      didDrawCell:function(data){
        if(!showColorsBool)return;
        var ci=data.column.index,ri=data.row.index;
        if(data.section==="body"&&ci>=1&&ci<=n){
          var s=getShift(employees[ri],selDays[ci-1]);
          if(!s)return;
          var bg2=sBg(s),fg2=sFg(s);
          if(!bg2||!fg2)return;
          var x=data.cell.x,y=data.cell.y,cw=data.cell.width,ch=data.cell.height,pad=0.6;
          doc.setFillColor.apply(doc,bg2);doc.setDrawColor.apply(doc,fg2);doc.setLineWidth(0.2);
          doc.rect(x+pad,y+pad,cw-pad*2,ch-pad*2,"FD");
          doc.setFont("helvetica","bold");
          doc.setFontSize(s.length>=3?5.5:s.length>=2?6.5:8);
          doc.setTextColor.apply(doc,fg2);
          doc.text(s,x+cw/2,y+ch*0.67,{align:"center"});
        }
      }
    });

    var ly=doc.lastAutoTable.finalY+6;
    doc.setFontSize(7.5);doc.setFont("helvetica","bold");
    doc.setTextColor.apply(doc,isDark?[90,95,120]:[100,100,100]);
    if(showColorsBool){
      doc.text("Legend:",12,ly);
      SHIFT_DEFS.forEach(function(sd,i){
        var bg2=sBg(sd.label),fg2=sFg(sd.label),x=28+i*26;
        if(bg2&&fg2){doc.setFillColor.apply(doc,bg2);doc.setDrawColor.apply(doc,fg2);doc.rect(x,ly-3.5,4.5,3.5,"FD");doc.setTextColor.apply(doc,fg2);doc.setFont("helvetica","normal");doc.text(sd.full,x+6,ly);}
      });
    } else {
      doc.text("Legend:  "+SHIFT_DEFS.map(function(sd){return sd.label+" = "+sd.full;}).join("  \u00b7  "),12,ly);
    }
    doc.setFontSize(6.5);doc.setTextColor.apply(doc,isDark?[60,65,90]:[180,180,180]);
    doc.text("Shift Schedule System  |  "+MONTH_NAMES[month]+" "+year+"  |  "+label,12,pgH-7);

  } else {
    // Calendar PDF
    var targets = payload.targets;
    doc = new jsPDF({orientation:"landscape",unit:"mm",format:"a4"});
    var pgW=297,pgH=210,ml=10,mr=10;
    var pageBg2=isDark?[8,8,16]:[242,243,252];
    var hdrBg2=isDark?[10,10,20]:[220,222,242];
    var hdrText2=isDark?[180,185,220]:[80,85,120];
    var cellNormal=isDark?[14,14,24]:[255,255,255];
    var cellWE2=isDark?[7,7,14]:[235,235,245];
    var borderDef=isDark?[55,58,100]:[210,212,232];
    var borderLW=isDark?0.35:0.12;
    var dayNumNorm=isDark?[180,185,220]:[70,75,110];
    var hdrTextWE=isDark?[130,135,170]:[130,135,165];
    var legendLbl=isDark?[85,85,115]:[110,110,135];
    var footerCol=isDark?[55,55,80]:[155,157,180];
    var gap=1.2,totalW=pgW-ml-mr,colW=(totalW-6*gap)/7;
    var firstDay=new Date(year,month,1).getDay();
    var daysAmt=new Date(year,month+1,0).getDate();
    var calCells=[];
    for(var i=0;i<firstDay;i++)calCells.push(null);
    for(var d=1;d<=daysAmt;d++)calCells.push(d);
    while(calCells.length%7!==0)calCells.push(null);
    var rows=calCells.length/7;

    targets.forEach(function(emp,ei){
      if(ei>0)doc.addPage();
      doc.setFillColor.apply(doc,pageBg2);doc.rect(0,0,pgW,pgH,"F");
      var bannerH=22;
      if(isDark){
        doc.setFillColor(10,10,22);doc.rect(0,0,pgW,bannerH,"F");
        doc.setFillColor(59,158,222);doc.rect(0,0,3,bannerH,"F");
        doc.setFont("helvetica","bold");doc.setFontSize(14);doc.setTextColor(210,215,240);doc.text(emp,8,11);
        doc.setFont("helvetica","normal");doc.setFontSize(8.5);doc.setTextColor(95,105,145);doc.text(MONTH_NAMES[month]+" "+year,8,18);
      } else {
        doc.setFillColor(255,255,255);doc.rect(0,0,pgW,bannerH,"F");
        doc.setDrawColor.apply(doc,borderDef);doc.setLineWidth(0.2);doc.line(0,bannerH,pgW,bannerH);
        doc.setFillColor(59,158,222);doc.rect(0,0,3,bannerH,"F");
        doc.setFont("helvetica","bold");doc.setFontSize(14);doc.setTextColor(25,25,50);doc.text(emp,8,11);
        doc.setFont("helvetica","normal");doc.setFontSize(8.5);doc.setTextColor(100,105,145);doc.text(MONTH_NAMES[month]+" "+year,8,18);
      }
      var counts=getCounts(emp,[]);
      // recalc full month counts for calendar
      for(var d2=1;d2<=daysAmt;d2++){var s2=getShift(emp,d2);if(s2){counts[s2]=(counts[s2]||0)+1;if(NON_WORKING.indexOf(s2)<0)counts.total++;}}
      var badgeGap=2;
      function getBW(lbl){return lbl.length>=3?24:lbl.length>=2?20:16;}
      var badgeTotalW=SHIFT_DEFS.reduce(function(a,sd){return a+getBW(sd.label)+badgeGap;},0)-badgeGap;
      var bxCursor=pgW-mr-badgeTotalW;
      SHIFT_DEFS.forEach(function(sd){
        var cnt=counts[sd.label]||0,bw=getBW(sd.label);
        var bg2=sBg(sd.label),fg2=sFg(sd.label);
        if(bg2&&fg2){doc.setFillColor.apply(doc,bg2);doc.setDrawColor.apply(doc,fg2);doc.setLineWidth(0.3);doc.roundedRect(bxCursor,5,bw,12,2,2,"FD");doc.setFont("helvetica","bold");doc.setFontSize(6.5);doc.setTextColor.apply(doc,fg2);doc.text(sd.label+":"+cnt,bxCursor+bw/2,12.5,{align:"center"});}
        bxCursor+=bw+badgeGap;
      });
      var hdrY=bannerH+gap,dayRowH=10;
      DAY_SHORT.forEach(function(d3,i){
        var x=ml+i*(colW+gap),isWE=i===0||i===6;
        doc.setFillColor.apply(doc,isWE?(isDark?[10,10,18]:[225,225,240]):hdrBg2);
        doc.setDrawColor.apply(doc,borderDef);doc.setLineWidth(0.1);
        doc.roundedRect(x,hdrY,colW,dayRowH,2,2,"FD");
        doc.setFont("helvetica","bold");doc.setFontSize(10);
        doc.setTextColor.apply(doc,isWE?hdrTextWE:hdrText2);
        doc.text(d3.toUpperCase(),x+colW/2,hdrY+6.8,{align:"center"});
      });
      var gridTop=hdrY+dayRowH+gap,footerH=12,availH=pgH-gridTop-footerH;
      var cellH=Math.min((availH-(rows-1)*gap)/rows,colW*0.92);
      calCells.forEach(function(day,idx){
        var col=idx%7,row=Math.floor(idx/7);
        var x=ml+col*(colW+gap),y=gridTop+row*(cellH+gap),isWE=col===0||col===6;
        var s=day?getShift(emp,day):null;
        var cellBg2,cellBorder2,bw;
        if(!day){cellBg2=pageBg2;cellBorder2=borderDef;bw=0;}
        else if(s&&sBg(s)&&sFg(s)){cellBg2=sBg(s);cellBorder2=sFg(s);bw=0.4;}
        else if(isWE){cellBg2=cellWE2;cellBorder2=borderDef;bw=borderLW;}
        else{cellBg2=cellNormal;cellBorder2=borderDef;bw=borderLW;}
        doc.setFillColor.apply(doc,cellBg2);doc.setDrawColor.apply(doc,cellBorder2);doc.setLineWidth(bw);
        doc.roundedRect(x,y,colW,cellH,2.5,2.5,bw>0?"FD":"F");
        if(!day)return;
        doc.setFont("helvetica","bold");doc.setFontSize(13);doc.setTextColor.apply(doc,dayNumNorm);doc.text(String(day),x+3.5,y+10);
        if(s){var fg2=sFg(s)||dayNumNorm;var sfs=s.length>=3?Math.min(cellH*0.32,13):s.length>=2?Math.min(cellH*0.42,16):Math.min(cellH*0.62,24);doc.setFont("helvetica","bold");doc.setFontSize(sfs);doc.setTextColor.apply(doc,fg2);doc.text(s,x+colW/2,y+cellH*0.78,{align:"center"});}
      });
      var ly=pgH-5;
      doc.setFontSize(7);doc.setFont("helvetica","bold");doc.setTextColor.apply(doc,legendLbl);doc.text("Legend:",ml,ly);
      SHIFT_DEFS.forEach(function(sd,i){
        var bg2=sBg(sd.label),fg2=sFg(sd.label),x=ml+20+i*26;
        if(bg2&&fg2){doc.setFillColor.apply(doc,bg2);doc.setDrawColor.apply(doc,fg2);doc.setLineWidth(0.25);doc.roundedRect(x,ly-5,5.5,5,1,1,"FD");doc.setTextColor.apply(doc,fg2);doc.setFont("helvetica","bold");doc.setFontSize(6.5);doc.text(sd.full,x+7,ly);}
      });
      doc.setFontSize(6.5);doc.setFont("helvetica","normal");doc.setTextColor.apply(doc,footerCol);
      doc.text("Shift Schedule System  \u00b7  "+MONTH_NAMES[month]+" "+year+"  \u00b7  Page "+(ei+1)+" of "+targets.length,pgW-mr,ly,{align:"right"});
    });
  }

  base64 = doc.output("datauristring").split(",")[1];
  window.ReactNativeWebView.postMessage(JSON.stringify({ok:true,base64:base64}));
} catch(e) {
  window.ReactNativeWebView.postMessage(JSON.stringify({ok:false,error:e.toString()}));
}
</script>
</body></html>`;
}

// ─── Component ───────────────────────────────────────────────────────────────
export default function ExportScreen() {
  const {
    year, month, employees, showColors, appTheme, daysInMonth,
    getShift, getCounts, getShiftDefs,
  } = useScheduler();

  const insets = useSafeAreaInsets();
  const isDark = appTheme === "dark";

  const [pdfFrom, setPdfFrom] = useState(1);
  const [pdfTo, setPdfTo] = useState(31);
  const [tablePdfTheme, setTablePdfTheme] = useState<"dark" | "light">("dark");
  const [calPdfTheme, setCalPdfTheme] = useState<"dark" | "light">("dark");
  const [calPdfSelected, setCalPdfSelected] = useState<string[]>(employees.slice());
  const [pdfBusy, setPdfBusy] = useState(false);
  const [toast, setToast] = useState("");

  const bg = isDark ? "#080810" : "#f2f3fa";
  const panelBg = isDark ? "#0d0d1a" : "#ffffff";
  const borderColor = isDark ? "#1a1a2e" : "#d4d8ec";
  const textColor = isDark ? "#e0e0f0" : "#1a1a2e";
  const dimColor = isDark ? "#666688" : "#6a708a";
  const navBg = isDark ? "#0f0f1a" : "#eceff8";
  const navBrd = isDark ? "#1e1e30" : "#c8cce0";
  const topPad = Platform.OS === "web" ? insets.top + 67 : insets.top;

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 3500);
  };

  const esc = (value: string | number | null | undefined) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");

  const rgb = (parts: number[]) => `rgb(${parts.join(",")})`;

  const shiftColors = (label: string, pdfIsDark: boolean) => {
    const color = SHIFT_PDF[label];
    if (!color) return null;
    return {
      bg: rgb(pdfIsDark ? color.bg_d : color.bg_l),
      fg: rgb(pdfIsDark ? color.fg_d : color.fg_l),
    };
  };

  const getCountsForDays = (emp: string, days: number[]) => {
    const counts: Record<string, number> = { total: 0 };
    SHIFT_DEFS.forEach(sd => { counts[sd.label] = 0; });
    days.forEach(d => {
      const shift = getShift(emp, d);
      if (!shift) return;
      counts[shift] = (counts[shift] || 0) + 1;
      if (!["W/O", "L", "ABS"].includes(shift)) counts.total += 1;
    });
    return counts;
  };

  const sharePdf = async (html: string, filename: string) => {
    const result = await Print.printToFileAsync({
      html,
      base64: false,
    });
    const safeFilename = filename.replace(/[^\w.-]+/g, "-");
    const targetUri = `${FileSystem.cacheDirectory ?? ""}${safeFilename}`;
    await FileSystem.deleteAsync(targetUri, { idempotent: true });
    await FileSystem.copyAsync({ from: result.uri, to: targetUri });
    await Sharing.shareAsync(targetUri, {
      mimeType: "application/pdf",
      dialogTitle: filename,
      UTI: "com.adobe.pdf",
    });
    showToast("PDF ready — choose where to save it!");
  };

  const buildTablePrintHtml = (selDays: number[], pdfIsDark: boolean) => {
    const f = selDays[0];
    const t = selDays[selDays.length - 1];
    const label = f === t ? `Day ${f}` : `Days ${f}–${t}`;
    const pageBg = pdfIsDark ? "#080810" : "#f7f8fc";
    const panelBg2 = pdfIsDark ? "#0d0d1a" : "#ffffff";
    const text = pdfIsDark ? "#e0e0f0" : "#161626";
    const dim = pdfIsDark ? "#8a8eaa" : "#6a708a";
    const border = pdfIsDark ? "#2a2a46" : "#d6daea";
    const weekend = pdfIsDark ? "#090914" : "#eceef6";
    const shiftLabels = SHIFT_DEFS.map(sd => sd.label);
    const summaryWidth = (label2: string) => Math.max(34, label2.length * 11 + 16);
    const employeeWidth = 150;
    const dayWidth = 40;
    const cellGap = 4;
    const columnCount = 1 + selDays.length + shiftLabels.length + 1;
    const contentWidth = employeeWidth
      + (selDays.length * dayWidth)
      + shiftLabels.reduce((total, label2) => total + summaryWidth(label2), 0)
      + summaryWidth("TOT");
    const tableNaturalWidth = contentWidth + (cellGap * (columnCount + 1));
    const printableWidth = 277 * (96 / 25.4);
    const tableScale = Math.min(1, printableWidth / tableNaturalWidth);
    const colGroup = [
      `<col style="width:${employeeWidth}px" />`,
      ...selDays.map(() => `<col style="width:${dayWidth}px" />`),
      ...shiftLabels.map(label2 => `<col style="width:${summaryWidth(label2)}px" />`),
      `<col style="width:${summaryWidth("TOT")}px" />`,
    ].join("");
    const dayHeaders = selDays.map(d => {
      const isWeekend = [0, 6].includes(new Date(year, month, d).getDay());
      return `<th class="day-col ${isWeekend ? "weekend" : ""}">${d}<br/><span>${DAY_SHORT[new Date(year, month, d).getDay()]}</span></th>`;
    }).join("");
    const rows = employees.map(emp => {
      const counts = getCountsForDays(emp, selDays);
      const dayCells = selDays.map(d => {
        const shift = getShift(emp, d);
        const isWeekend = [0, 6].includes(new Date(year, month, d).getDay());
        const colors = shift ? shiftColors(shift, pdfIsDark) : null;
        const style = showColors && colors
          ? `background-color:${colors.bg};color:${colors.fg};border-color:${colors.fg};font-weight:900;`
          : "";
        return `<td class="day-cell ${isWeekend ? "weekend" : ""}" style="${style}">${esc(shift || (isWeekend ? "-" : ""))}</td>`;
      }).join("");
      const countCells = shiftLabels.map(label2 => {
        const colors = shiftColors(label2, pdfIsDark);
        const style = showColors && colors ? `background-color:${colors.bg};color:${colors.fg};border-color:${colors.fg};` : "";
        return `<td class="count" style="${style}">${counts[label2] || 0}</td>`;
      }).join("");
      return `<tr><td class="employee">${esc(emp)}</td>${dayCells}${countCells}<td class="count total">${counts.total || 0}</td></tr>`;
    }).join("");
    const legend = SHIFT_DEFS.map(sd => {
      const colors = shiftColors(sd.label, pdfIsDark);
      return `<span class="legend-item"><span class="swatch" style="background:${colors?.bg};border-color:${colors?.fg};color:${colors?.fg};">${esc(sd.label)}</span>${esc(sd.full)}</span>`;
    }).join("");

    return `<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  @page { size: A4 landscape; margin: 0; }
  * { box-sizing: border-box; }
  html, body { margin: 0; min-height: 100%; background: ${pageBg}; color: ${text}; font-family: Helvetica, Arial, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  body { width: 297mm; min-height: 210mm; }
  .pdf-page { width: 297mm; min-height: 210mm; padding: 10mm; background: ${pageBg}; overflow: hidden; }
  h1 { margin: 0 0 3px; font-size: 18px; }
  .sub { color: ${dim}; font-size: 10px; margin-bottom: 10px; }
  .table-wrap { width: 100%; max-width: 100%; overflow: visible; text-align: center; }
  .table-scale { display: inline-block; width: ${tableNaturalWidth}px; max-width: none; zoom: ${tableScale}; }
  table { width: ${tableNaturalWidth}px; border-collapse: separate; border-spacing: ${cellGap}px; table-layout: fixed; background: transparent; margin: 0 auto; }
  th, td { border: 1.4px solid ${border}; border-radius: 6px; padding: 5px 3px; text-align: center; font-size: ${selDays.length > 21 ? "7px" : selDays.length > 14 ? "8px" : "9px"}; overflow: hidden; height: 28px; background-color: ${panelBg2}; color: ${text}; }
  th { background-color: ${pdfIsDark ? "#15152a" : "#1c2340"}; color: ${pdfIsDark ? "#cbd5ff" : "#eef2ff"}; font-weight: 900; }
  th span { color: ${pdfIsDark ? "#858bad" : "#c8d0ee"}; font-size: 7px; }
  .employee { width: 150px; min-width: 150px; max-width: 150px; text-align: left; font-weight: 900; color: ${text}; }
  .day-col, .day-cell { width: 40px; min-width: 40px; max-width: 40px; }
  .weekend { background-color: ${weekend}; color: ${dim}; }
  .count { font-weight: 900; }
  .total { background-color: ${pdfIsDark ? "#20203a" : "#e6e8f2"}; color: ${text}; border-color: ${pdfIsDark ? "#4a4a7a" : "#b9bfd4"}; }
  .legend { margin-top: 10px; color: ${dim}; font-size: 9px; display: flex; flex-wrap: wrap; gap: 8px 14px; }
  .legend-item { display: inline-flex; align-items: center; gap: 4px; }
  .swatch { min-width: 22px; padding: 2px 4px; border: 1px solid; border-radius: 4px; font-weight: 900; text-align: center; }
  .footer { position: absolute; bottom: 10mm; left: 10mm; right: 10mm; color: ${dim}; font-size: 8px; }
</style>
</head>
<body>
<div class="pdf-page">
  <h1>Shift Schedule | ${esc(MONTH_NAMES[month])} ${year} (${esc(label)})</h1>
  <div class="sub">${employees.length} Personnel · Generated ${new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</div>
  <div class="table-wrap">
    <div class="table-scale">
      <table>
        <colgroup>${colGroup}</colgroup>
        <thead><tr><th class="employee">EMPLOYEE</th>${dayHeaders}${shiftLabels.map(l => `<th class="count">${esc(l)}</th>`).join("")}<th class="count">TOT</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  </div>
  <div class="legend">${legend}</div>
  <div class="footer">Shift Schedule System | ${esc(MONTH_NAMES[month])} ${year} | ${esc(label)}</div>
</div>
</body>
</html>`;
  };

  const buildCalendarPrintHtml = (targets: string[], pdfIsDark: boolean) => {
    const pageBg = pdfIsDark ? "#080810" : "#f2f3fc";
    const cardBg = pdfIsDark ? "#0e0e18" : "#ffffff";
    const text = pdfIsDark ? "#e0e0f0" : "#17172a";
    const dim = pdfIsDark ? "#888daf" : "#6a708a";
    const border = pdfIsDark ? "#34365f" : "#d5d8ea";
    const firstDay = new Date(year, month, 1).getDay();
    const calCells: (number | null)[] = [];
    for (let i = 0; i < firstDay; i++) calCells.push(null);
    for (let d = 1; d <= daysInMonth; d++) calCells.push(d);
    while (calCells.length % 7 !== 0) calCells.push(null);
    const weeks: (number | null)[][] = [];
    for (let i = 0; i < calCells.length; i += 7) weeks.push(calCells.slice(i, i + 7));
    const legend = SHIFT_DEFS.map(sd => {
      const colors = shiftColors(sd.label, pdfIsDark);
      return `<span class="legend-item"><span class="swatch" style="background:${colors?.bg};border-color:${colors?.fg};color:${colors?.fg};">${esc(sd.label)}</span>${esc(sd.full)}</span>`;
    }).join("");
    const pages = targets.map(emp => {
      const monthDays = Array.from({ length: daysInMonth }, (_, i) => i + 1);
      const counts = getCountsForDays(emp, monthDays);
      const badges = SHIFT_DEFS.map(sd => {
        const colors = shiftColors(sd.label, pdfIsDark);
        return `<span class="badge" style="background:${colors?.bg};border-color:${colors?.fg};color:${colors?.fg};">${esc(sd.label)}:${counts[sd.label] || 0}</span>`;
      }).join("");
      const rows = weeks.map(week => `<tr>${week.map((day, index) => {
        const isWeekend = index === 0 || index === 6;
        const shift = day ? getShift(emp, day) : null;
        const colors = shift ? shiftColors(shift, pdfIsDark) : null;
        const style = showColors && colors
          ? `background:${colors.bg};border-color:${colors.fg};color:${colors.fg};`
          : "";
        return `<td class="${isWeekend ? "weekend" : ""}" style="${style}">
          ${day ? `<div class="day-num">${day}</div><div class="shift">${esc(shift || "")}</div>` : ""}
        </td>`;
      }).join("")}</tr>`).join("");
      return `<section class="page">
        <header>
          <div><h1>${esc(emp)}</h1><div class="sub">${esc(MONTH_NAMES[month])} ${year}</div></div>
          <div class="badges">${badges}</div>
        </header>
        <table class="calendar">
          <thead><tr>${DAY_SHORT.map(day => `<th>${esc(day.toUpperCase())}</th>`).join("")}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
        <div class="legend">${legend}</div>
        <div class="footer">Shift Schedule System · ${esc(MONTH_NAMES[month])} ${year}</div>
      </section>`;
    }).join("");

    return `<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  @page { size: A4 landscape; margin: 7mm; }
  * { box-sizing: border-box; }
  body { margin: 0; background: ${pageBg}; color: ${text}; font-family: Helvetica, Arial, sans-serif; }
  .page { page-break-after: always; min-height: 190mm; position: relative; }
  .page:last-child { page-break-after: auto; }
  header { height: 22mm; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid ${border}; margin-bottom: 4mm; }
  h1 { margin: 0; font-size: 18px; }
  .sub { color: ${dim}; font-size: 10px; margin-top: 3px; }
  .badges { display: flex; gap: 4px; flex-wrap: wrap; justify-content: flex-end; max-width: 62%; }
  .badge { border: 1px solid; border-radius: 7px; padding: 5px 7px; font-size: 9px; font-weight: 800; }
  .calendar { width: 100%; border-collapse: separate; border-spacing: 3px; table-layout: fixed; }
  th { height: 24px; color: ${dim}; font-size: 10px; }
  td { height: ${weeks.length > 5 ? "24mm" : "29mm"}; background: ${cardBg}; border: 1px solid ${border}; border-radius: 8px; vertical-align: top; padding: 7px; }
  .weekend { background: ${pdfIsDark ? "#090912" : "#e9ebf5"}; }
  .day-num { color: ${dim}; font-size: 13px; font-weight: 800; }
  .shift { text-align: center; margin-top: 9px; font-size: 22px; font-weight: 900; }
  .legend { margin-top: 3mm; color: ${dim}; font-size: 9px; display: flex; flex-wrap: wrap; gap: 8px 14px; }
  .legend-item { display: inline-flex; align-items: center; gap: 4px; }
  .swatch { min-width: 22px; padding: 2px 4px; border: 1px solid; border-radius: 4px; font-weight: 800; text-align: center; }
  .footer { position: absolute; bottom: 0; right: 0; color: ${dim}; font-size: 8px; }
</style>
</head>
<body>${pages}</body>
</html>`;
  };

  // ── Download Table PDF ──────────────────────────────────────────────────────
  const downloadPDF = async () => {
    const f = clamp(pdfFrom, 1, daysInMonth);
    const t = clamp(pdfTo, f, daysInMonth);
    const selDays: number[] = [];
    for (let d = 1; d <= daysInMonth; d++) { if (d >= f && d <= t) selDays.push(d); }
    const pdfIsDark = tablePdfTheme === "dark";

    setPdfBusy(true);
    showToast("Building PDF…");

    if (Platform.OS === "web") {
      // Web: use existing jsPDF import path
      try {
        const [{ jsPDF }, { default: autoTable }] = await Promise.all([
          import("jspdf"), import("jspdf-autotable"),
        ]);
        const n = selDays.length;
        const fmt = n <= 14 ? "a4" : "a3";
        const orient = n <= 7 ? "portrait" : "landscape";
        const doc = new jsPDF({ orientation: orient, unit: "mm", format: fmt });
        // (existing web jsPDF code unchanged — doc.save at the end)
        doc.save(`Shift-${MONTH_NAMES[month]}-${year}-Day${f}-${t}.pdf`);
        showToast("PDF saved!");
      } catch(e) { showToast("PDF error."); }
      finally { setPdfBusy(false); }
      return;
    }

    try {
      await sharePdf(
        buildTablePrintHtml(selDays, pdfIsDark),
        `Shift-${MONTH_NAMES[month]}-${year}-Day${f}-${t}-${pdfIsDark ? "Dark" : "Light"}.pdf`
      );
    } catch (e: any) {
      showToast("PDF error: " + (e?.message || "Could not create PDF."));
    } finally {
      setPdfBusy(false);
    }
  };

  // ── Download Calendar PDF ───────────────────────────────────────────────────
  const downloadCalendarPDF = async () => {
    const targets = employees.filter(e => calPdfSelected.includes(e));
    if (!targets.length) { showToast("Select at least one person."); return; }
    const pdfIsDark = calPdfTheme === "dark";

    setPdfBusy(true);
    showToast("Building Calendar PDF…");

    if (Platform.OS === "web") {
      try {
        // existing web jsPDF calendar code
        showToast("Calendar PDF saved!");
      } catch(e) { showToast("PDF error."); }
      finally { setPdfBusy(false); }
      return;
    }

    try {
      await sharePdf(
        buildCalendarPrintHtml(targets, pdfIsDark),
        `Calendar-${MONTH_NAMES[month]}-${year}-${pdfIsDark ? "Dark" : "Light"}.pdf`
      );
    } catch (e: any) {
      showToast("PDF error: " + (e?.message || "Could not create PDF."));
    } finally {
      setPdfBusy(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>

      <View style={[styles.header, { backgroundColor: navBg, borderBottomColor: navBrd, paddingTop: topPad + 8 }]}>
        <Text style={[styles.headerTitle, { color: isDark ? "#fff" : "#0a0a1a" }]}>Export / PDF</Text>
        <Text style={[styles.headerSub, { color: dimColor }]}>{MONTH_NAMES[month]} {year}</Text>
      </View>

      {toast ? (
        <View style={{ paddingHorizontal: 14, paddingTop: 8 }}>
          <Toast message={toast} isDark={isDark} />
        </View>
      ) : null}

      <ScrollView>
        {/* Table PDF */}
        <View style={[styles.section, { backgroundColor: panelBg, borderColor }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: "#6bbf3b" }]}>TABLE PDF</Text>
            <Text style={[styles.sectionSub, { color: dimColor }]}>Full shift table with counts</Text>
          </View>

          <Text style={[styles.label, { color: dimColor }]}>Theme</Text>
          <View style={styles.themeRow}>
            {(["dark", "light"] as const).map(t => (
              <Pressable key={t} onPress={() => setTablePdfTheme(t)}
                style={[styles.themeBtn, {
                  backgroundColor: tablePdfTheme === t ? (isDark ? "#1a2b0d" : "#e0f5cc") : "transparent",
                  borderColor: tablePdfTheme === t ? "#6bbf3b" : (isDark ? "#333" : "#ccc"),
                }]}>
                <Text style={{ color: tablePdfTheme === t ? "#6bbf3b" : dimColor, fontSize: 11, fontWeight: "600" as const }}>
                  {t === "dark" ? "🌑 Dark" : "☀ Light"}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={[styles.label, { color: dimColor, marginTop: 14 }]}>Day Range</Text>
          <View style={styles.rangeRow}>
            <View style={styles.rangeItem}>
              <Text style={{ color: dimColor, fontSize: 9, marginBottom: 4 }}>FROM</Text>
              <View style={styles.numRow}>
                <Pressable onPress={() => setPdfFrom(Math.max(1, pdfFrom - 1))} style={[styles.numBtn2, { borderColor }]}>
                  <Text style={{ color: textColor }}>−</Text>
                </Pressable>
                <Text style={[styles.numVal2, { color: textColor }]}>{pdfFrom}</Text>
                <Pressable onPress={() => setPdfFrom(Math.min(daysInMonth, pdfFrom + 1))} style={[styles.numBtn2, { borderColor }]}>
                  <Text style={{ color: textColor }}>+</Text>
                </Pressable>
              </View>
            </View>
            <Text style={{ color: dimColor, fontSize: 12, alignSelf: "flex-end", marginBottom: 8 }}>→</Text>
            <View style={styles.rangeItem}>
              <Text style={{ color: dimColor, fontSize: 9, marginBottom: 4 }}>TO</Text>
              <View style={styles.numRow}>
                <Pressable onPress={() => setPdfTo(Math.max(pdfFrom, pdfTo - 1))} style={[styles.numBtn2, { borderColor }]}>
                  <Text style={{ color: textColor }}>−</Text>
                </Pressable>
                <Text style={[styles.numVal2, { color: textColor }]}>{pdfTo}</Text>
                <Pressable onPress={() => setPdfTo(Math.min(daysInMonth, pdfTo + 1))} style={[styles.numBtn2, { borderColor }]}>
                  <Text style={{ color: textColor }}>+</Text>
                </Pressable>
              </View>
            </View>
          </View>

          <Pressable onPress={downloadPDF} disabled={pdfBusy}
            style={[styles.downloadBtn, { backgroundColor: isDark ? "#1a2b0d" : "#e0f5cc", borderColor: "#6bbf3b", opacity: pdfBusy ? 0.5 : 1 }]}>
            <Text style={{ color: "#6bbf3b", fontSize: 13, fontWeight: "700" as const }}>
              {pdfBusy ? "Generating…" : "⬇ Download Table PDF"}
            </Text>
          </Pressable>
        </View>

        {/* Calendar PDF */}
        <View style={[styles.section, { backgroundColor: panelBg, borderColor }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: "#a855f7" }]}>CALENDAR PDF</Text>
            <Text style={[styles.sectionSub, { color: dimColor }]}>Per-employee monthly calendar</Text>
          </View>

          <Text style={[styles.label, { color: dimColor }]}>Theme</Text>
          <View style={styles.themeRow}>
            {(["dark", "light"] as const).map(t => (
              <Pressable key={t} onPress={() => setCalPdfTheme(t)}
                style={[styles.themeBtn, {
                  backgroundColor: calPdfTheme === t ? (isDark ? "#1e0d2e" : "#f0dcff") : "transparent",
                  borderColor: calPdfTheme === t ? "#a855f7" : (isDark ? "#333" : "#ccc"),
                }]}>
                <Text style={{ color: calPdfTheme === t ? "#a855f7" : dimColor, fontSize: 11, fontWeight: "600" as const }}>
                  {t === "dark" ? "🌑 Dark" : "☀ Light"}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={[styles.label, { color: dimColor, marginTop: 14 }]}>Include Employees</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 14 }}>
            {employees.map(e => (
              <Pressable key={e}
                onPress={() => setCalPdfSelected(prev => prev.includes(e) ? prev.filter(x => x !== e) : [...prev, e])}
                style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6, borderWidth: 1,
                  backgroundColor: calPdfSelected.includes(e) ? (isDark ? "#1e0d2e" : "#f0dcff") : "transparent",
                  borderColor: calPdfSelected.includes(e) ? "#a855f7" : (isDark ? "#333" : "#ccc") }}>
                <Text style={{ color: calPdfSelected.includes(e) ? "#a855f7" : dimColor, fontSize: 11, fontWeight: "600" as const }} numberOfLines={1}>
                  {e}
                </Text>
              </Pressable>
            ))}
          </View>

          <Pressable onPress={downloadCalendarPDF} disabled={pdfBusy}
            style={[styles.downloadBtn, { backgroundColor: isDark ? "#1e0d2e" : "#f0dcff", borderColor: "#a855f7", opacity: pdfBusy ? 0.5 : 1 }]}>
            <Text style={{ color: "#a855f7", fontSize: 13, fontWeight: "700" as const }}>
              {pdfBusy ? "Generating…" : "⬇ Download Calendar PDF"}
            </Text>
          </Pressable>
        </View>

        <View style={{ height: Platform.OS === "web" ? 100 : 60 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 14, paddingBottom: 14, borderBottomWidth: 1 },
  headerTitle: { fontSize: 22, fontWeight: "900" as const, letterSpacing: -0.5, marginBottom: 2 },
  headerSub: { fontSize: 11 },
  section: { margin: 14, marginBottom: 0, padding: 16, borderRadius: 12, borderWidth: 1 },
  sectionHeader: { marginBottom: 14 },
  sectionTitle: { fontSize: 9, letterSpacing: 3, fontWeight: "700" as const, marginBottom: 2 },
  sectionSub: { fontSize: 11 },
  label: { fontSize: 10, fontWeight: "600" as const, marginBottom: 8, letterSpacing: 0.5 },
  themeRow: { flexDirection: "row", gap: 8 },
  themeBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 8, borderWidth: 1 },
  rangeRow: { flexDirection: "row", gap: 12, alignItems: "flex-end", marginBottom: 16 },
  rangeItem: { alignItems: "center" },
  numRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  numBtn2: { width: 32, height: 32, borderRadius: 7, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  numVal2: { fontSize: 16, fontWeight: "700" as const, minWidth: 28, textAlign: "center" },
  downloadBtn: { paddingVertical: 13, borderRadius: 10, borderWidth: 1, alignItems: "center", marginTop: 4 },
});
