import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useSchedule, SHIFT_DEFS, DEFAULT_EMPLOYEES } from "@/context/ScheduleContext";
import { useColors } from "@/hooks/useColors";

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { employees, addEmployee, removeEmployee, showColors, setShowColors, resetAll } = useSchedule();
  const [newEmpName, setNewEmpName] = useState("");

  const isDark = colors.background === "#080810";

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleAdd = () => {
    const err = addEmployee(newEmpName);
    if (err) {
      Alert.alert("Error", err);
    } else {
      setNewEmpName("");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleRemove = (emp: string) => {
    Alert.alert("Remove Employee", `Remove "${emp}" from the schedule?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove", style: "destructive", onPress: () => {
          removeEmployee(emp);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        }
      },
    ]);
  };

  const handleReset = () => {
    Alert.alert("Reset All Data", "Erase ALL saved schedules and employees?\nThis cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Reset", style: "destructive", onPress: () => {
          resetAll();
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        }
      },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.navBg, borderBottomColor: colors.navBorder }]}>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Settings</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 14, paddingTop: 16, paddingBottom: botPad + 100 }}>
        {/* Personnel Card */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>PERSONNEL ({employees.length})</Text>

          {/* Add employee */}
          <View style={styles.addRow}>
            <TextInput
              value={newEmpName}
              onChangeText={setNewEmpName}
              onSubmitEditing={handleAdd}
              placeholder="Full name (tap Add or Enter)"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.nameInput, { color: colors.text, backgroundColor: colors.background, borderColor: colors.border, fontFamily: "Inter_400Regular" }]}
              autoCapitalize="characters"
            />
            <TouchableOpacity onPress={handleAdd} style={[styles.addBtn, { borderColor: colors.primary }]}>
              <Text style={[styles.addBtnText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>+ Add</Text>
            </TouchableOpacity>
          </View>

          {employees.length === 0 && (
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No employees yet.</Text>
          )}

          {employees.map((emp, i) => (
            <View key={emp} style={[styles.empRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.empNum, { color: colors.dim2 }]}>{i + 1}.</Text>
              <Text style={[styles.empName, { color: colors.text, fontFamily: "Inter_500Medium" }]} numberOfLines={1}>{emp}</Text>
              <TouchableOpacity onPress={() => handleRemove(emp)} style={styles.removeBtn}>
                <Feather name="x" size={16} color={colors.destructive} />
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {/* Shift Types Card */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>SHIFT TYPES</Text>

          {SHIFT_DEFS.map((sd) => (
            <View key={sd.label} style={[styles.shiftRow, { borderBottomColor: colors.border }]}>
              <View style={[styles.shiftIcon, { backgroundColor: sd.bg, borderColor: sd.border }]}>
                <Text style={[styles.shiftIconText, { color: sd.text, fontFamily: "Inter_700Bold", fontSize: sd.label === "W/O" ? 10 : 16 }]}>{sd.label}</Text>
              </View>
              <View>
                <Text style={[styles.shiftFull, { color: sd.text, fontFamily: "Inter_700Bold" }]}>{sd.full}</Text>
                <Text style={[styles.shiftSub, { color: colors.mutedForeground }]}>Fixed shift type</Text>
              </View>
            </View>
          ))}

          {/* Colors toggle */}
          <View style={[styles.toggleRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.toggleLabel, { color: colors.text, fontFamily: "Inter_500Medium" }]}>Color Coding</Text>
            <TouchableOpacity
              onPress={() => { setShowColors(!showColors); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
              style={[styles.toggle, { backgroundColor: showColors ? colors.primary : colors.border }]}
            >
              <View style={[styles.toggleKnob, { transform: [{ translateX: showColors ? 18 : 2 }] }]} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Quick Guide */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>QUICK GUIDE</Text>
          <View style={styles.guideItem}>
            <Feather name="edit-2" size={13} color={colors.primary} />
            <Text style={[styles.guideText, { color: colors.dim2 }]}>Tap any cell to assign A / B / C / W/O or clear</Text>
          </View>
          <View style={styles.guideItem}>
            <Feather name="layers" size={13} color={colors.primary} />
            <Text style={[styles.guideText, { color: colors.dim2 }]}>Bulk Assign (icon in header) — set range + shift + target → Apply</Text>
          </View>
          <View style={styles.guideItem}>
            <Feather name="zap" size={13} color="#6bbf3b" />
            <Text style={[styles.guideText, { color: colors.dim2 }]}>Auto-generate rotates A/B/C shifts automatically</Text>
          </View>
          <View style={styles.guideItem}>
            <Feather name="refresh-cw" size={13} color="#a855f7" />
            <Text style={[styles.guideText, { color: colors.dim2 }]}>Table & Calendar are always in sync • Auto-saved</Text>
          </View>
        </View>

        {/* Reset */}
        <TouchableOpacity onPress={handleReset} style={[styles.resetBtn, { borderColor: colors.destructive }]}>
          <Feather name="alert-triangle" size={16} color={colors.destructive} />
          <Text style={[styles.resetBtnText, { color: colors.destructive, fontFamily: "Inter_600SemiBold" }]}>Reset All Saved Data</Text>
        </TouchableOpacity>

        <Text style={[styles.credit, { color: colors.dim3 }]}>
          Shift Scheduler — All data stored locally on device
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 14, paddingBottom: 10, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18 },
  card: { borderRadius: 12, borderWidth: 1, padding: 14, marginBottom: 14, gap: 0 },
  cardLabel: { fontSize: 9, letterSpacing: 3, textTransform: "uppercase", marginBottom: 12, fontWeight: "600" },
  addRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  nameInput: { flex: 1, height: 38, borderRadius: 8, borderWidth: 1, paddingHorizontal: 12, fontSize: 12 },
  addBtn: { paddingHorizontal: 14, height: 38, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  addBtnText: { fontSize: 12 },
  emptyText: { fontSize: 12, paddingVertical: 8 },
  empRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10, borderBottomWidth: 1, gap: 8 },
  empNum: { fontSize: 10, width: 22 },
  empName: { flex: 1, fontSize: 12 },
  removeBtn: { padding: 4 },
  shiftRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12, borderBottomWidth: 1, gap: 12 },
  shiftIcon: { width: 44, height: 44, borderRadius: 8, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  shiftIconText: { fontWeight: "900" },
  shiftFull: { fontSize: 14 },
  shiftSub: { fontSize: 10, marginTop: 2 },
  toggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 14, marginTop: 4, borderTopWidth: 1 },
  toggleLabel: { fontSize: 13 },
  toggle: { width: 42, height: 24, borderRadius: 12, justifyContent: "center" },
  toggleKnob: { width: 20, height: 20, borderRadius: 10, backgroundColor: "#fff" },
  guideItem: { flexDirection: "row", gap: 10, alignItems: "flex-start", paddingVertical: 6 },
  guideText: { fontSize: 12, flex: 1, lineHeight: 18 },
  resetBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 10, borderWidth: 1, padding: 14, marginBottom: 16 },
  resetBtnText: { fontSize: 13 },
  credit: { fontSize: 10, textAlign: "center", marginBottom: 8 },
});
