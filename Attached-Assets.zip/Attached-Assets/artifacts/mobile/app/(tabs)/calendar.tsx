import * as Haptics from "expo-haptics";
import React, { useState, useMemo, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Pressable,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  useSchedule,
  SHIFT_DEFS,
  MONTH_NAMES,
  DAY_SHORT,
  ShiftLabel,
} from "@/context/ScheduleContext";
import { useColors } from "@/hooks/useColors";

const SHIFT_DEFS_LIGHT = [
  { label: "A", full: "A Shift", bg: "#dbeeff", border: "#3b9ede", text: "#1565c0" },
  { label: "B", full: "B Shift", bg: "#e1f7ce", border: "#6bbf3b", text: "#2e7d10" },
  { label: "C", full: "C Shift", bg: "#fff0d6", border: "#e0912a", text: "#b35a00" },
  { label: "W/O", full: "Week Off", bg: "#f3e0ff", border: "#a855f7", text: "#7c22cc" },
];

export default function CalendarScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    year, month, prevMonth, nextMonth,
    employees, daysAmt,
    getShift, setShift, showColors, counts,
  } = useSchedule();

  const isDark = colors.background === "#080810";
  const shiftDefs = isDark ? SHIFT_DEFS : SHIFT_DEFS_LIGHT;

  const today = new Date();

  const firstDay = useMemo(() => new Date(year, month, 1).getDay(), [year, month]);

  const calCells: (number | null)[] = useMemo(() => {
    const cells: (number | null)[] = [];
    for (let i = 0; i < firstDay; i++) cells.push(null);
    for (let d = 1; d <= daysAmt; d++) cells.push(d);
    return cells;
  }, [firstDay, daysAmt]);

  const [pickerVisible, setPickerVisible] = useState(false);
  const [pickerEmp, setPickerEmp] = useState("");
  const [pickerDay, setPickerDay] = useState(0);

  const openPicker = useCallback((emp: string, day: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPickerEmp(emp);
    setPickerDay(day);
    setPickerVisible(true);
  }, []);

  const pickShift = useCallback((val: ShiftLabel | null) => {
    setShift(pickerEmp, pickerDay, val);
    setPickerVisible(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }, [pickerEmp, pickerDay, setShift]);

  const getShiftDef = (label: string | null) => {
    if (!label) return null;
    return (shiftDefs as ReadonlyArray<{ label: string; bg: string; border: string; text: string }>).find((s) => s.label === label) ?? null;
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.navBg, borderBottomColor: colors.navBorder }]}>
        <View style={styles.monthNav}>
          <TouchableOpacity onPress={prevMonth} style={[styles.navBtn, { backgroundColor: colors.navBg, borderColor: colors.navBorder }]}>
            <Text style={[styles.navBtnText, { color: colors.dim }]}>‹</Text>
          </TouchableOpacity>
          <Text style={[styles.monthLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
            {MONTH_NAMES[month]} {year}
          </Text>
          <TouchableOpacity onPress={nextMonth} style={[styles.navBtn, { backgroundColor: colors.navBg, borderColor: colors.navBorder }]}>
            <Text style={[styles.navBtnText, { color: colors.dim }]}>›</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: botPad + 100, paddingHorizontal: 12, paddingTop: 12 }}>
        {employees.map((emp) => (
          <View key={emp} style={[styles.empSection, { borderColor: colors.border }]}>
            {/* Employee header */}
            <View style={[styles.empHeader, { backgroundColor: isDark ? "#0c0c1e" : "#eceff8" }]}>
              <Text style={[styles.empArrow, { color: colors.primary }]}>▸</Text>
              <Text style={[styles.empName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{emp}</Text>
              <View style={styles.countChips}>
                {(shiftDefs as ReadonlyArray<{ label: string; text: string }>).map((sd) => (
                  <Text key={sd.label} style={[styles.countChip, { color: sd.text, fontFamily: "Inter_700Bold" }]}>
                    {sd.label}:{counts[emp]?.[sd.label as keyof typeof counts[string]] || 0}
                  </Text>
                ))}
              </View>
            </View>

            {/* Day headers */}
            <View style={styles.calGrid}>
              {DAY_SHORT.map((d) => (
                <View key={d} style={styles.dayHeaderCell}>
                  <Text style={[styles.dayHeaderText, { color: isDark ? "#444455" : "#9090aa" }]}>{d.slice(0, 2)}</Text>
                </View>
              ))}

              {/* Calendar cells */}
              {calCells.map((day, i) => {
                if (!day) return <View key={`e${i}`} style={styles.calCell} />;
                const s = getShift(emp, day);
                const def = s ? getShiftDef(s) : null;
                const dow = new Date(year, month, day).getDay();
                const isWE = dow === 0 || dow === 6;
                const isTD = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();

                const cellBg = showColors
                  ? (def ? def.bg : isWE ? colors.weekendCell : (isDark ? "#0e0e18" : "#ffffff"))
                  : (isWE ? colors.weekendCell : (isDark ? "#0e0e18" : "#ffffff"));

                const borderColor = isTD ? colors.todayBorder : (showColors && def ? def.border : colors.border);
                const borderWidth = isTD ? 1.5 : 1;

                return (
                  <TouchableOpacity
                    key={day}
                    onPress={() => openPicker(emp, day)}
                    style={[styles.calCell, { backgroundColor: cellBg, borderColor, borderWidth }]}
                  >
                    <Text style={[styles.calDayNum, { color: isTD ? colors.todayHeaderText : (isDark ? "#3a3a5a" : "#aaaacc"), fontWeight: isTD ? "700" : "400" }]}>{day}</Text>
                    {s ? (
                      <Text style={[styles.calShiftLabel, { color: showColors ? def!.text : (isDark ? "#ccccdd" : "#444"), fontFamily: "Inter_700Bold" }]}>{s}</Text>
                    ) : (
                      <Text style={[styles.calOffText, { color: isWE ? (isDark ? "#1a1a2a" : "#ccccdd") : (isDark ? "#1e1e30" : "#ddddee") }]}>
                        {isWE ? "OFF" : "—"}
                      </Text>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Shift Picker Modal */}
      <Modal visible={pickerVisible} transparent animationType="fade" onRequestClose={() => setPickerVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setPickerVisible(false)}>
          <Pressable style={[styles.pickerPanel, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={(e) => e.stopPropagation()}>
            <Text style={[styles.pickerTitle, { color: colors.mutedForeground, fontFamily: "Inter_600SemiBold" }]}>
              {pickerEmp} — Day {pickerDay}
            </Text>
            <View style={styles.pickerGrid}>
              {SHIFT_DEFS.map((sd) => (
                <TouchableOpacity
                  key={sd.label}
                  onPress={() => pickShift(sd.label as ShiftLabel)}
                  style={[styles.pickerBtn, { backgroundColor: sd.bg, borderColor: sd.border }]}
                >
                  <Text style={[styles.pickerBtnText, { color: sd.text, fontFamily: "Inter_700Bold" }]}>{sd.label}</Text>
                  <Text style={[styles.pickerBtnSub, { color: sd.text }]}>{sd.full}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity onPress={() => pickShift(null)} style={[styles.clearBtn, { borderColor: colors.border }]}>
              <Text style={[styles.clearBtnText, { color: colors.mutedForeground }]}>Clear</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 14, paddingBottom: 10, borderBottomWidth: 1 },
  monthNav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  navBtn: { width: 34, height: 34, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  navBtnText: { fontSize: 22, lineHeight: 28 },
  monthLabel: { fontSize: 15, letterSpacing: 0.3 },
  empSection: { marginBottom: 20, borderRadius: 10, borderWidth: 1, overflow: "hidden" },
  empHeader: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 8, gap: 6, flexWrap: "wrap" },
  empArrow: { fontSize: 10 },
  empName: { fontSize: 11, flex: 1 },
  countChips: { flexDirection: "row", gap: 8 },
  countChip: { fontSize: 9 },
  calGrid: { flexDirection: "row", flexWrap: "wrap", padding: 6, gap: 3 },
  dayHeaderCell: { width: "13.6%", alignItems: "center", paddingVertical: 3 },
  dayHeaderText: { fontSize: 8, letterSpacing: 1.5, fontWeight: "600" },
  calCell: { width: "13.6%", borderRadius: 5, padding: 3, aspectRatio: 0.85, alignItems: "center" },
  calDayNum: { fontSize: 7, alignSelf: "flex-end", lineHeight: 10 },
  calShiftLabel: { fontSize: 11, lineHeight: 14 },
  calOffText: { fontSize: 6, lineHeight: 10 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", alignItems: "center", justifyContent: "center" },
  pickerPanel: { width: 280, borderRadius: 12, borderWidth: 1, padding: 16, gap: 12 },
  pickerTitle: { fontSize: 12, textAlign: "center" },
  pickerGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center" },
  pickerBtn: { width: 110, borderRadius: 10, borderWidth: 1.5, padding: 12, alignItems: "center", gap: 4 },
  pickerBtnText: { fontSize: 18 },
  pickerBtnSub: { fontSize: 10 },
  clearBtn: { borderRadius: 8, borderWidth: 1, padding: 10, alignItems: "center" },
  clearBtnText: { fontSize: 13 },
});
