import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState, useMemo, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Platform,
  Alert,
  Pressable,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  useSchedule,
  SHIFT_DEFS,
  MONTH_NAMES,
  DAY_SHORT,
  ShiftLabel,
} from "@/context/ScheduleContext";
import { useColors } from "@/hooks/useColors";

const SHIFT_COLORS_LIGHT = [
  { label: "A", full: "A Shift", bg: "#dbeeff", border: "#3b9ede", text: "#1565c0" },
  { label: "B", full: "B Shift", bg: "#e1f7ce", border: "#6bbf3b", text: "#2e7d10" },
  { label: "C", full: "C Shift", bg: "#fff0d6", border: "#e0912a", text: "#b35a00" },
  { label: "W/O", full: "Week Off", bg: "#f3e0ff", border: "#a855f7", text: "#7c22cc" },
];

export default function ScheduleScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    year, month, prevMonth, nextMonth,
    employees, daysAmt, clamp,
    getShift, setShift, autoGenerate, clearMonth, applyBulk,
    showColors, counts,
  } = useSchedule();

  const today = new Date();
  const isDark = colors.background === "#080810";
  const shiftDefs = isDark ? SHIFT_DEFS : SHIFT_COLORS_LIGHT;

  const days = useMemo(() => Array.from({ length: daysAmt }, (_, i) => i + 1), [daysAmt]);

  const [pickerVisible, setPickerVisible] = useState(false);
  const [pickerEmp, setPickerEmp] = useState("");
  const [pickerDay, setPickerDay] = useState(0);

  const [bulkVisible, setBulkVisible] = useState(false);
  const [bFrom, setBFrom] = useState("1");
  const [bTo, setBTo] = useState("7");
  const [bShift, setBShift] = useState<ShiftLabel | "off">("A");
  const [bTarget, setBTarget] = useState("all");

  const openPicker = useCallback((emp: string, day: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPickerEmp(emp);
    setPickerDay(day);
    setPickerVisible(true);
  }, []);

  const pickShift = useCallback((val: ShiftLabel | null) => {
    setShift(pickerEmp, pickerDay, val);
    setPickerVisible(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }, [pickerEmp, pickerDay, setShift]);

  const handleAutoGenerate = () => {
    autoGenerate();
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("Done", `Schedule generated for ${MONTH_NAMES[month]} ${year}`);
  };

  const handleClearMonth = () => {
    Alert.alert("Clear Month", "Clear all shifts for this month?", [
      { text: "Cancel", style: "cancel" },
      { text: "Clear", style: "destructive", onPress: () => { clearMonth(); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } },
    ]);
  };

  const handleApplyBulk = () => {
    const f = clamp(parseInt(bFrom) || 1, 1, daysAmt);
    const t = clamp(parseInt(bTo) || 1, f, daysAmt);
    applyBulk(f, t, bShift, bTarget);
    setBulkVisible(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const getShiftDef = (label: string | null) => {
    if (!label) return null;
    return (shiftDefs as ReadonlyArray<{ label: string; full: string; bg: string; border: string; text: string }>).find((s) => s.label === label) ?? null;
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.navBg, borderBottomColor: colors.navBorder }]}>
        <View style={styles.headerTop}>
          <Text style={[styles.appTitle, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>Shift Scheduler</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity onPress={handleAutoGenerate} style={[styles.iconBtn, { borderColor: colors.navBorder }]}>
              <Feather name="zap" size={17} color="#6bbf3b" />
            </TouchableOpacity>
            <TouchableOpacity onPress={handleClearMonth} style={[styles.iconBtn, { borderColor: colors.navBorder }]}>
              <Feather name="trash-2" size={17} color={colors.destructive} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setBulkVisible(true)} style={[styles.iconBtn, { borderColor: colors.navBorder, backgroundColor: isDark ? "#0d1a2e" : "#dbeeff" }]}>
              <Feather name="layers" size={17} color={colors.primary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Month nav */}
        <View style={styles.monthNav}>
          <TouchableOpacity onPress={prevMonth} style={[styles.navBtn, { backgroundColor: colors.navBg, borderColor: colors.navBorder }]}>
            <Feather name="chevron-left" size={20} color={colors.dim} />
          </TouchableOpacity>
          <Text style={[styles.monthLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
            {MONTH_NAMES[month]} {year}
          </Text>
          <TouchableOpacity onPress={nextMonth} style={[styles.navBtn, { backgroundColor: colors.navBg, borderColor: colors.navBorder }]}>
            <Feather name="chevron-right" size={20} color={colors.dim} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Table */}
      <ScrollView style={styles.tableOuter} horizontal showsHorizontalScrollIndicator>
        <View>
          {/* Table header */}
          <View style={styles.tableRow}>
            <View style={[styles.empCell, styles.thCell, { backgroundColor: colors.tableHeader, borderBottomColor: colors.border, borderRightColor: colors.border }]}>
              <Text style={[styles.thText, { color: colors.headerText }]}>Employee</Text>
            </View>
            {days.map((d) => {
              const dow = new Date(year, month, d).getDay();
              const isWE = dow === 0 || dow === 6;
              const isTD = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
              const bg = isTD ? colors.todayHeader : isWE ? (isDark ? "#0a0a14" : "#e0e4f2") : colors.tableHeader;
              const tc = isTD ? colors.todayHeaderText : isWE ? colors.weekendText : colors.headerText;
              return (
                <View key={d} style={[styles.dayThCell, { backgroundColor: bg, borderBottomColor: colors.border }]}>
                  <Text style={[styles.dayThNum, { color: tc }]}>{d}</Text>
                  <Text style={[styles.dayThDow, { color: tc }]}>{DAY_SHORT[dow].slice(0, 2)}</Text>
                </View>
              );
            })}
            {(shiftDefs as ReadonlyArray<{ label: string; bg: string; border: string; text: string }>).map((sd) => (
              <View key={sd.label} style={[styles.sumTh, { backgroundColor: showColors ? sd.bg : (isDark ? "#0a0a14" : "#e0e4f2"), borderBottomColor: colors.border }]}>
                <Text style={[styles.sumThText, { color: showColors ? sd.text : colors.headerText }]}>{sd.label}</Text>
              </View>
            ))}
            <View style={[styles.sumTh, { backgroundColor: isDark ? "#0a0a14" : "#e0e4f2", borderBottomColor: colors.border }]}>
              <Text style={[styles.sumThText, { color: colors.dim3 }]}>TOT</Text>
            </View>
          </View>

          {/* Employee rows */}
          <ScrollView style={{ maxHeight: 500 }} nestedScrollEnabled showsVerticalScrollIndicator>
            {employees.map((emp, ri) => {
              const rowBg = ri % 2 === 0 ? colors.panel2 : colors.rowBg;
              const empBg = ri % 2 === 0 ? colors.panel : colors.empBg;
              return (
                <View key={emp} style={[styles.tableRow, { backgroundColor: rowBg }]}>
                  <View style={[styles.empCell, { backgroundColor: empBg, borderRightColor: colors.border }]}>
                    <Text style={[styles.empNum, { color: colors.dim2 }]}>{ri + 1}. </Text>
                    <Text style={[styles.empName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>{emp}</Text>
                  </View>
                  {days.map((d) => {
                    const s = getShift(emp, d);
                    const def = s ? getShiftDef(s) : null;
                    const dow = new Date(year, month, d).getDay();
                    const isWE = dow === 0 || dow === 6;
                    const isTD = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();

                    let cellBg = "transparent";
                    let cellText = colors.dim3;
                    if (showColors && def) { cellBg = def.bg; cellText = def.text; }
                    else if (isWE) { cellBg = colors.weekendCell; cellText = colors.weekendText; }
                    else if (isTD && !def) { cellBg = colors.todayCell; }

                    return (
                      <TouchableOpacity
                        key={d}
                        onPress={() => openPicker(emp, d)}
                        style={[
                          styles.dayCell,
                          { backgroundColor: cellBg, borderLeftColor: isTD ? colors.todayBorder : colors.border },
                        ]}
                      >
                        <Text style={[styles.dayCellText, { color: cellText, fontFamily: "Inter_700Bold" }]}>
                          {s || (isWE ? "·" : "–")}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                  {(shiftDefs as ReadonlyArray<{ label: string; bg: string; text: string }>).map((sd) => {
                    const cnt = counts[emp]?.[sd.label as keyof typeof counts[string]] || 0;
                    return (
                      <View key={sd.label} style={[styles.sumCell, { backgroundColor: showColors && cnt ? sd.bg : "transparent", borderLeftColor: colors.border }]}>
                        <Text style={[styles.sumCellText, { color: showColors && cnt ? sd.text : colors.dim3, fontFamily: "Inter_700Bold" }]}>
                          {cnt || "–"}
                        </Text>
                      </View>
                    );
                  })}
                  <View style={[styles.sumCell, { borderLeftColor: colors.border }]}>
                    <Text style={[styles.sumCellText, { color: colors.dim, fontFamily: "Inter_600SemiBold" }]}>
                      {counts[emp]?.total || 0}
                    </Text>
                  </View>
                </View>
              );
            })}
          </ScrollView>

          {/* Legend */}
          <View style={[styles.legend, { borderTopColor: colors.border }]}>
            {(shiftDefs as ReadonlyArray<{ label: string; full: string; bg: string; border: string; text: string }>).map((sd) => (
              <View key={sd.label} style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: sd.bg, borderColor: sd.border }]} />
                <Text style={[styles.legendText, { color: colors.dim2 }]}>{sd.full}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      <View style={{ height: botPad + 84 }} />

      {/* Shift Picker Modal */}
      <Modal visible={pickerVisible} transparent animationType="fade" onRequestClose={() => setPickerVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setPickerVisible(false)}>
          <Pressable style={[styles.pickerPanel, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={(e) => e.stopPropagation()}>
            <Text style={[styles.pickerTitle, { color: colors.mutedForeground, fontFamily: "Inter_600SemiBold" }]}>
              {pickerEmp} — Day {pickerDay}
            </Text>
            <View style={styles.pickerGrid}>
              {SHIFT_DEFS.map((sd) => (
                <TouchableOpacity
                  key={sd.label}
                  onPress={() => pickShift(sd.label as ShiftLabel)}
                  style={[styles.pickerBtn, { backgroundColor: sd.bg, borderColor: sd.border }]}
                >
                  <Text style={[styles.pickerBtnText, { color: sd.text, fontFamily: "Inter_700Bold" }]}>{sd.label}</Text>
                  <Text style={[styles.pickerBtnSub, { color: sd.text }]}>{sd.full}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity onPress={() => pickShift(null)} style={[styles.clearBtn, { borderColor: colors.border }]}>
              <Text style={[styles.clearBtnText, { color: colors.mutedForeground }]}>Clear</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Bulk Assign Modal */}
      <Modal visible={bulkVisible} transparent animationType="slide" onRequestClose={() => setBulkVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setBulkVisible(false)}>
          <Pressable style={[styles.bulkPanel, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={(e) => e.stopPropagation()}>
            <Text style={[styles.bulkTitle, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>Bulk Assign</Text>

            <View style={styles.bulkRow}>
              <Text style={[styles.bulkLabel, { color: colors.mutedForeground }]}>Day</Text>
              <TextInput
                value={bFrom}
                onChangeText={setBFrom}
                keyboardType="number-pad"
                style={[styles.numInput, { color: colors.text, backgroundColor: colors.background, borderColor: colors.border }]}
              />
              <Text style={[styles.bulkLabel, { color: colors.mutedForeground }]}>to</Text>
              <TextInput
                value={bTo}
                onChangeText={setBTo}
                keyboardType="number-pad"
                style={[styles.numInput, { color: colors.text, backgroundColor: colors.background, borderColor: colors.border }]}
              />
            </View>

            <View style={styles.shiftRow}>
              {[...SHIFT_DEFS, { label: "off", full: "Off", bg: "transparent", border: colors.border, text: colors.dim2 } as const].map((sd) => (
                <TouchableOpacity
                  key={sd.label}
                  onPress={() => setBShift(sd.label as ShiftLabel | "off")}
                  style={[
                    styles.shiftChip,
                    {
                      backgroundColor: bShift === sd.label ? sd.bg : "transparent",
                      borderColor: bShift === sd.label ? sd.border : colors.border,
                    },
                  ]}
                >
                  <Text style={[styles.shiftChipText, { color: bShift === sd.label ? sd.text : colors.mutedForeground, fontFamily: "Inter_700Bold" }]}>
                    {sd.label === "off" ? "Off" : sd.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={[styles.pickerSelect, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <ScrollView style={{ maxHeight: 160 }} nestedScrollEnabled>
                {["all", ...employees].map((emp) => (
                  <TouchableOpacity
                    key={emp}
                    onPress={() => setBTarget(emp)}
                    style={[styles.targetItem, { borderBottomColor: colors.border, backgroundColor: bTarget === emp ? (isDark ? "#0d1a2e" : "#dbeeff") : "transparent" }]}
                  >
                    <Text style={[styles.targetText, { color: bTarget === emp ? colors.primary : colors.text }]}>
                      {emp === "all" ? "All Employees" : emp}
                    </Text>
                    {bTarget === emp && <Feather name="check" size={14} color={colors.primary} />}
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>

            <View style={styles.bulkActions}>
              <TouchableOpacity onPress={() => setBulkVisible(false)} style={[styles.bulkCancelBtn, { borderColor: colors.border }]}>
                <Text style={[styles.bulkCancelText, { color: colors.mutedForeground }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleApplyBulk} style={[styles.bulkApplyBtn, { backgroundColor: "#6bbf3b" }]}>
                <Text style={[styles.bulkApplyText, { fontFamily: "Inter_700Bold" }]}>Apply</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 14, paddingBottom: 10, borderBottomWidth: 1 },
  headerTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  appTitle: { fontSize: 18, letterSpacing: 0.5 },
  headerActions: { flexDirection: "row", gap: 8 },
  iconBtn: { width: 34, height: 34, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  monthNav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  navBtn: { width: 34, height: 34, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  monthLabel: { fontSize: 15, letterSpacing: 0.3 },
  tableOuter: { flex: 1 },
  tableRow: { flexDirection: "row" },
  thCell: { borderBottomWidth: 1, borderRightWidth: 1 },
  empCell: { width: 130, paddingVertical: 8, paddingHorizontal: 10, flexDirection: "row", alignItems: "center", borderRightWidth: 1 },
  empNum: { fontSize: 9 },
  empName: { fontSize: 10, flex: 1 },
  thText: { fontSize: 9, fontWeight: "600", letterSpacing: 0.5 },
  dayThCell: { width: 28, alignItems: "center", justifyContent: "center", paddingVertical: 5, borderBottomWidth: 1 },
  dayThNum: { fontSize: 9, fontWeight: "700" },
  dayThDow: { fontSize: 6, marginTop: 1 },
  dayCell: { width: 28, height: 36, alignItems: "center", justifyContent: "center", borderLeftWidth: 1 },
  dayCellText: { fontSize: 8 },
  sumTh: { width: 30, alignItems: "center", justifyContent: "center", paddingVertical: 5, borderBottomWidth: 1 },
  sumThText: { fontSize: 8, fontWeight: "800" },
  sumCell: { width: 30, height: 36, alignItems: "center", justifyContent: "center", borderLeftWidth: 1 },
  sumCellText: { fontSize: 8 },
  legend: { flexDirection: "row", flexWrap: "wrap", padding: 10, gap: 12, borderTopWidth: 1 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  legendDot: { width: 11, height: 11, borderRadius: 3, borderWidth: 2 },
  legendText: { fontSize: 10 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", alignItems: "center", justifyContent: "center" },
  pickerPanel: { width: 280, borderRadius: 12, borderWidth: 1, padding: 16, gap: 12 },
  pickerTitle: { fontSize: 12, textAlign: "center" },
  pickerGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center" },
  pickerBtn: { width: 110, borderRadius: 10, borderWidth: 1.5, padding: 12, alignItems: "center", gap: 4 },
  pickerBtnText: { fontSize: 18 },
  pickerBtnSub: { fontSize: 10 },
  clearBtn: { borderRadius: 8, borderWidth: 1, padding: 10, alignItems: "center" },
  clearBtnText: { fontSize: 13 },
  bulkPanel: { width: "90%", maxWidth: 360, borderRadius: 14, borderWidth: 1, padding: 18, gap: 14 },
  bulkTitle: { fontSize: 16, textAlign: "center" },
  bulkRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  bulkLabel: { fontSize: 13 },
  numInput: { width: 52, height: 38, textAlign: "center", borderRadius: 8, borderWidth: 1, fontSize: 13 },
  shiftRow: { flexDirection: "row", gap: 6, flexWrap: "wrap" },
  shiftChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8, borderWidth: 1.5 },
  shiftChipText: { fontSize: 12 },
  pickerSelect: { borderRadius: 8, borderWidth: 1, overflow: "hidden" },
  targetItem: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 12, paddingVertical: 10, borderBottomWidth: 1 },
  targetText: { fontSize: 12 },
  bulkActions: { flexDirection: "row", gap: 10 },
  bulkCancelBtn: { flex: 1, borderRadius: 8, borderWidth: 1, padding: 12, alignItems: "center" },
  bulkCancelText: { fontSize: 13 },
  bulkApplyBtn: { flex: 1, borderRadius: 8, padding: 12, alignItems: "center" },
  bulkApplyText: { fontSize: 13, color: "#fff" },
});
