import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

const STORAGE_KEY = "shiftScheduler.v1";

export const DEFAULT_EMPLOYEES = [
  "D CHELLAPPA",
  "SURYA KANTA MEDOK",
  "RAJ KUMAR",
  "MONIRAM SAIKIA",
  "RUPAM PAUL",
  "NAGABUSHAN",
  "RATHINA KUMAR",
  "RAJESH KUMAR JENA",
  "KARTHIK GOSWAMI",
];

export const SHIFT_DEFS = [
  { label: "A", full: "A Shift", bg: "#0d2137", border: "#3b9ede", text: "#3b9ede" },
  { label: "B", full: "B Shift", bg: "#1a2b0d", border: "#6bbf3b", text: "#6bbf3b" },
  { label: "C", full: "C Shift", bg: "#2b1a0d", border: "#e0912a", text: "#e0912a" },
  { label: "W/O", full: "Week Off", bg: "#1e0d2e", border: "#a855f7", text: "#a855f7" },
] as const;

export type ShiftLabel = "A" | "B" | "C" | "W/O";
export type ShiftDef = (typeof SHIFT_DEFS)[number];

export type MonthSchedule = Record<string, Record<number, ShiftLabel | null>>;
export type FullSchedule = Record<string, MonthSchedule>;

export const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export const DAY_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function getDaysInMonth(y: number, m: number) {
  return new Date(y, m + 1, 0).getDate();
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

interface ScheduleContextType {
  year: number;
  month: number;
  setYear: (y: number) => void;
  setMonth: (m: number) => void;
  prevMonth: () => void;
  nextMonth: () => void;
  employees: string[];
  addEmployee: (name: string) => string | null;
  removeEmployee: (name: string) => void;
  schedule: FullSchedule;
  getShift: (emp: string, day: number) => ShiftLabel | null;
  setShift: (emp: string, day: number, val: ShiftLabel | null) => void;
  autoGenerate: () => void;
  clearMonth: () => void;
  applyBulk: (from: number, to: number, shift: ShiftLabel | "off", target: string) => void;
  showColors: boolean;
  setShowColors: (v: boolean) => void;
  counts: Record<string, { A: number; B: number; C: number; "W/O": number; off: number; total: number }>;
  daysAmt: number;
  getDaysInMonth: (y: number, m: number) => number;
  clamp: (v: number, lo: number, hi: number) => number;
  resetAll: () => void;
}

const ScheduleContext = createContext<ScheduleContextType | null>(null);

export function ScheduleProvider({ children }: { children: React.ReactNode }) {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [employees, setEmployees] = useState<string[]>(DEFAULT_EMPLOYEES);
  const [schedule, setSchedule] = useState<FullSchedule>({});
  const [showColors, setShowColors] = useState(true);
  const loadedRef = useRef(false);

  const mKey = `${year}-${month}`;
  const daysAmt = getDaysInMonth(year, month);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          const data = JSON.parse(raw);
          if (data.schedule && typeof data.schedule === "object") setSchedule(data.schedule);
          if (Array.isArray(data.employees) && data.employees.length) setEmployees(data.employees);
          if (typeof data.showColors === "boolean") setShowColors(data.showColors);
        } catch {}
      }
      loadedRef.current = true;
    });
  }, []);

  useEffect(() => {
    if (!loadedRef.current) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ schedule, employees, showColors })).catch(() => {});
  }, [schedule, employees, showColors]);

  const prevMonth = useCallback(() => {
    if (month === 0) { setMonth(11); setYear((y) => y - 1); }
    else setMonth((m) => m - 1);
  }, [month]);

  const nextMonth = useCallback(() => {
    if (month === 11) { setMonth(0); setYear((y) => y + 1); }
    else setMonth((m) => m + 1);
  }, [month]);

  const getShift = useCallback((emp: string, day: number): ShiftLabel | null => {
    return (schedule[mKey]?.[emp]?.[day] ?? null) as ShiftLabel | null;
  }, [schedule, mKey]);

  const setShift = useCallback((emp: string, day: number, val: ShiftLabel | null) => {
    setSchedule((p) => ({
      ...p,
      [mKey]: {
        ...p[mKey],
        [emp]: { ...(p[mKey]?.[emp] || {}), [day]: val },
      },
    }));
  }, [mKey]);

  const addEmployee = useCallback((name: string): string | null => {
    const n = name.trim().toUpperCase();
    if (!n) return "Enter a name first.";
    if (employees.indexOf(n) !== -1) return "Already in the list.";
    setEmployees((p) => [...p, n]);
    return null;
  }, [employees]);

  const removeEmployee = useCallback((name: string) => {
    setEmployees((p) => p.filter((x) => x !== name));
  }, []);

  const autoGenerate = useCallback(() => {
    const gen: MonthSchedule = {};
    const abc = SHIFT_DEFS.filter((s) => s.label !== "W/O");
    employees.forEach((emp, ei) => {
      gen[emp] = {};
      for (let d = 1; d <= daysAmt; d++) {
        const dow = new Date(year, month, d).getDay();
        gen[emp][d] = (dow === 0 || dow === 6) ? null : (abc[(ei + Math.floor((d - 1) / 3)) % 3].label as ShiftLabel);
      }
    });
    setSchedule((p) => ({ ...p, [mKey]: gen }));
  }, [employees, daysAmt, year, month, mKey]);

  const clearMonth = useCallback(() => {
    setSchedule((p) => ({ ...p, [mKey]: {} }));
  }, [mKey]);

  const applyBulk = useCallback((from: number, to: number, shift: ShiftLabel | "off", target: string) => {
    const f = clamp(from, 1, daysAmt);
    const t = clamp(to, f, daysAmt);
    const val: ShiftLabel | null = shift === "off" ? null : shift;
    const targets = target === "all" ? employees : [target];
    setSchedule((p) => {
      const mo = { ...(p[mKey] || {}) };
      targets.forEach((emp) => {
        mo[emp] = { ...(mo[emp] || {}) };
        for (let d = f; d <= t; d++) mo[emp][d] = val;
      });
      return { ...p, [mKey]: mo };
    });
  }, [employees, daysAmt, mKey]);

  const counts = React.useMemo(() => {
    const c: Record<string, { A: number; B: number; C: number; "W/O": number; off: number; total: number }> = {};
    employees.forEach((emp) => {
      c[emp] = { A: 0, B: 0, C: 0, "W/O": 0, off: 0, total: 0 };
      for (let d = 1; d <= daysAmt; d++) {
        const s = getShift(emp, d);
        const dow = new Date(year, month, d).getDay();
        if (s) {
          c[emp][s] = (c[emp][s] || 0) + 1;
          if (s !== "W/O") c[emp].total++;
        } else if (dow !== 0 && dow !== 6) {
          c[emp].off++;
        }
      }
    });
    return c;
  }, [schedule, employees, mKey, daysAmt, year, month, getShift]);

  const resetAll = useCallback(() => {
    setSchedule({});
    setEmployees(DEFAULT_EMPLOYEES);
    AsyncStorage.removeItem(STORAGE_KEY).catch(() => {});
  }, []);

  return (
    <ScheduleContext.Provider value={{
      year, month, setYear, setMonth, prevMonth, nextMonth,
      employees, addEmployee, removeEmployee,
      schedule, getShift, setShift, autoGenerate, clearMonth, applyBulk,
      showColors, setShowColors,
      counts, daysAmt, getDaysInMonth, clamp, resetAll,
    }}>
      {children}
    </ScheduleContext.Provider>
  );
}

export function useSchedule() {
  const ctx = useContext(ScheduleContext);
  if (!ctx) throw new Error("useSchedule must be used within ScheduleProvider");
  return ctx;
}
